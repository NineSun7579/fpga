module cat_add #(
    parameter CHA_PAR_IN = 16,                           //����ͨ�����ж�
              INT = 8,
              DATA_WIDTH = CHA_PAR_IN * INT,             //���ݴ���λ��    ���벢�ж� * INT8
              //�߶�λ��//
              SCALE_WIDTH = 16,                          //scale��λ��
              SCALE_FRACTION_WIDTH = 15,                 //scale��С��λ��
              //�˷����ӳ�
              MUL_DELAY = 4

)
(
    input         clk         ,
    input         rst         ,

    input         start       ,

    //�߶���zero
    input  [SCALE_WIDTH-1 : 0] scale_1,
    input  [SCALE_WIDTH-1 : 0] scale_2,
    input  [SCALE_WIDTH*2-1 : 0] scale_3,           //16λС�� 32λ����16λС + 16λ����
    input  [INT-1 : 0] zero_1        ,
    input  [INT-1 : 0] zero_2        ,


    input [DATA_WIDTH-1 : 0] s_data_0  ,
    input [DATA_WIDTH-1 : 0] s_data_1  ,
    input                    s_valid_0 ,
    input                    s_valid_1 ,
    input                    s_last    ,


    output [DATA_WIDTH-1 : 0]  m_data  ,
    output                     m_valid ,
    output                     m_last


);
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
    localparam SCALE_DELAY = 1;
    reg [SCALE_WIDTH-1 : 0] scale_d[0 : 1][0 : SCALE_DELAY-1];
    integer k;
    localparam SCALE_3_DELAY = 1 + MUL_DELAY + 1;
    reg [SCALE_WIDTH*2-1 : 0] scale_3_d[0 : SCALE_3_DELAY-1];
    reg [INT-1 : 0] sub_zero[CHA_PAR_IN-1 : 0][0 : 1];
    wire [INT+SCALE_WIDTH-1 : 0] scale_sub[CHA_PAR_IN-1 : 0][0 : 1];
    localparam CAT_DELAY = SCALE_3_DELAY - 1;
    reg [CAT_DELAY-1 : 0] s_valid_0_d, s_valid_1_d; 
    reg [INT+SCALE_WIDTH : 0] add_data[CHA_PAR_IN-1 : 0];
    wire [SCALE_WIDTH*2 + INT+SCALE_WIDTH : 0] q3[CHA_PAR_IN-1 : 0];
    reg [INT-1 : 0] m_data_r[CHA_PAR_IN-1 : 0];
    localparam ALL_DELAY = SCALE_3_DELAY + MUL_DELAY + 1;
    reg [ALL_DELAY-1 : 0] s_valid_d, s_last_d; 
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)


    // integer i;
// //////////////////////////��������///////////////////////////////////////
//     reg [INT-1 : 0] zero[0 : 1];
//     reg [SCALE_WIDTH-1 : 0] scale[0 : 1];
//     reg [SCALE_WIDTH*2-1 : 0] scale_add;            //��ǰģ��scale
//     always @(posedge clk) begin
//         if(start) begin
//             scale[0] <= scale_1;
//             scale[1] <= scale_2;
//             scale_add <= scale_3;
//             zero[0]  <= zero_1 ;
//             zero[1]  <= zero_2 ;
//         end
//     end

////////////////////////////�����ӳ�/////////////////////////////////////////
    //scale_1 2 �������ӳ�д��

    always @(posedge clk) begin
        if(rst) begin
            for (k = 0; k < SCALE_DELAY; k = k + 1) begin
                scale_d[0][k] <= 0;
            end
        end
        else begin
            if(s_valid_0) begin
               scale_d[0][0] <= scale_1; 
            end
            for (k = 1; k < SCALE_DELAY; k = k + 1) begin
                scale_d[0][k] <= scale_d[0][k-1];
            end
        end
    end

    always @(posedge clk) begin
        if(rst) begin
            for (k = 0; k < SCALE_DELAY; k = k + 1) begin
                scale_d[1][k] <= 0;
            end
        end
        else begin
            if(s_valid_1) begin
               scale_d[1][0] <= scale_2; 
            end
            for (k = 1; k < SCALE_DELAY; k = k + 1) begin
                scale_d[1][k] <= scale_d[1][k-1];
            end
        end
    end



    //scale_3 �������ӳ�д��
    //һ�ļ����ӳ� + scale1����2�˷����ӳ� + һ�ļӷ��ӳ�
    always @(posedge clk) begin
        if(rst) begin
            for (k = 0; k < SCALE_3_DELAY; k = k + 1) begin
                scale_3_d[k] <= 0;
            end
        end
        else begin
            scale_3_d[0] <= scale_3;
            for (k = 1; k < SCALE_3_DELAY; k = k + 1) begin
                scale_3_d[k] <= scale_3_d[k-1];
            end
        end
    end


/////////////////////////////////���ݼ���zero    1����////////////////////////////////
    //                          ͨ����       ��Ҫ��ȥzero����������
    genvar i;
    generate 
        for (i = 0; i < CHA_PAR_IN; i = i + 1) begin
            //sub_s_data_0
            always @(posedge clk) begin
                if(s_valid_0) begin
                    if(s_data_0[i * 8 +: 8] < zero_1) begin                //�����������Ǹ�
                        sub_zero[i][0] <= {INT{1'b0}};
                    end
                    else begin
                        sub_zero[i][0] <= s_data_0[i * 8 +: 8] - zero_1;
                    end
                end
            end
            //sub_s_data_1
            always @(posedge clk) begin
                if(s_valid_1) begin
                    if(s_data_1[i * 8 +: 8] < zero_2) begin                //�����������Ǹ�
                        sub_zero[i][1] <= {INT{1'b0}};
                    end
                    else begin
                        sub_zero[i][1] <= s_data_1[i * 8 +: 8] - zero_2;
                    end
                end
            end
        end
    endgenerate

///////////////////////////////////////////���ݷ�����   MUL_DELAY����//////////////////////////////////////////////////////
    generate
        for (i = 0; i < CHA_PAR_IN; i = i + 1) begin: SCALE_S1_AND_S2
            scale_mul_unsign #(
                .DATA_WIDTH(INT),
                .SCALE_WIDTH(SCALE_WIDTH),
                .DELAY(MUL_DELAY)
            )
            scale_mul_unsign_0(
                .clk(clk),
                .A(sub_zero[i][0]),
                .B(scale_d[0][SCALE_DELAY-1]),
                .P(scale_sub[i][0])
            );


            scale_mul_unsign #(
                .DATA_WIDTH(INT),
                .SCALE_WIDTH(SCALE_WIDTH),
                .DELAY(MUL_DELAY)
            )
            scale_mul_unsign_1(
                .clk(clk),
                .A(sub_zero[i][1]),
                .B(scale_d[1][SCALE_DELAY-1]),
                .P(scale_sub[i][1])
            );

        end
    endgenerate

///////////////////////////////////////////ADD����    1����//////////////////////////////////////////////////////
    always @(posedge clk) begin
        if(rst) begin
            s_valid_0_d <= 0;
            s_valid_1_d <= 0;
        end
        else begin
            s_valid_0_d <= {s_valid_0_d[CAT_DELAY-1 : 0] , s_valid_0};
            s_valid_1_d <= {s_valid_1_d[CAT_DELAY-1 : 0] , s_valid_1};
        end
    end

    generate
        for (i = 0; i < CHA_PAR_IN; i = i + 1) begin
            always @(posedge clk) begin
                if(s_valid_0_d[CAT_DELAY-1] & s_valid_1_d[CAT_DELAY-1]) begin
                    add_data[i] <= scale_sub[i][0] + scale_sub[i][1];
                end
                else if(s_valid_0_d[CAT_DELAY-1]) begin
                    add_data[i] <= scale_sub[i][0];
                end
                else if(s_valid_1_d[CAT_DELAY-1]) begin
                    add_data[i] <= scale_sub[i][1];
                end
            end
        end
    endgenerate


/////////////////////////////////////////�������� ����3    MUL_DELAY����//////////////////////////////////////
    generate
        for (i = 0; i < CHA_PAR_IN; i = i + 1) begin: SCALE_S3
            scale_mul_unsign_s3 #(
                .DATA_WIDTH(INT+SCALE_WIDTH+1),
                .SCALE_WIDTH(SCALE_WIDTH*2),
                .DELAY(MUL_DELAY)
            )
            scale_mul_unsign_3(
                .clk(clk),
                .A(add_data[i]),
                .B(scale_3_d[SCALE_3_DELAY-1]),
                .P(q3[i])
            );


            // mult_gen_0 mult_gen_3333(
            //     .CLK(clk),
            //     .A(add_data[i]),
            //     .B(scale_3_d[SCALE_3_DELAY-1]),
            //     .P(q3[i])
            // );
        end
    endgenerate


/////////////////////////////////////////���ݽض�    1����//////////////////////////////////////
    generate
        for (i = 0; i < CHA_PAR_IN; i = i + 1) begin

            always @(posedge clk) begin 
                if(q3[i][SCALE_WIDTH*2 + INT+SCALE_WIDTH : SCALE_FRACTION_WIDTH*2] >= 8'd255) begin
                    m_data_r[i] <= 8'd255;
                end
                else begin
                    m_data_r[i] <= q3[i][SCALE_FRACTION_WIDTH*2 + INT-1 : SCALE_FRACTION_WIDTH*2] + q3[i][SCALE_FRACTION_WIDTH*2-1];
                end
            end

        end
    endgenerate

 //////////////////////////////////////����ƴ�����////////////////////////////////////////
    generate
        for (i = 0; i < CHA_PAR_IN; i = i+1) begin
            assign m_data[i*8 +: 8] = m_data_r[i];
        end
    endgenerate

/////////////////////////////////��������ź��ӳ�////////////////////////////////
    //����ź��ӳ�  �����м�������ӳ� (scale3�ӳ� + scale3�ĳ˷����ӳ� + 1�����ݽض�)
    always @(posedge clk ) begin
        if(rst) begin
            s_valid_d <= 0;
            s_last_d <= 0;
        end
        else begin
            s_valid_d <= {s_valid_d[ALL_DELAY-1 : 0] , (s_valid_1 | s_valid_0)};
            s_last_d  <= {s_last_d[ALL_DELAY-1 : 0]  , s_last};
        end
    end

    assign m_valid = s_valid_d[ALL_DELAY-1];
    assign m_last = s_last_d[ALL_DELAY-1];



endmodule