module out_buf_ctrl #(
    parameter AXI_DATA_WIDTH = 32,
              AXI_ADDR_WIDTH = 32,
    parameter CHA_PAR_OUT = 8,                                      //���ͨ�����ж�
              CHA_IMG_OUT = 128,                                    //ͼƬ������ͨ����
              INT = 8,                                              //ÿ������λ��
              //conv
              CONV_CHA_PAR_OUT = 8,
              CONV_DATA_WIDTH  = CONV_CHA_PAR_OUT * INT,
              MAX_CALULATE_NUM = (CHA_IMG_OUT / CONV_CHA_PAR_OUT),       //�������
              CALULATE_CNT_WIDTH = $clog2(MAX_CALULATE_NUM),
              MAX_OUT_LEN = 5120,                                   //��ģ�������������ֽ���  Ҳ�������һ��*ͨ�����ֽ���
              LEN_WIDTH = $clog2(MAX_OUT_LEN),
              MAX_OUT_ROW = 320,                                    //�����IMG���������
              ROW_WIDTH = $clog2(MAX_OUT_ROW),
              DATA_WIDTH = CHA_PAR_OUT * INT,                       //���ݴ���λ��    ������ж� * INT8
              DATA_DEPTH = MAX_OUT_LEN / CHA_PAR_OUT                //�������  ������ W*channal/���ж�  RAM������Ӧ�ô���һ�����������ֽڸ���

)
(
    input         clk              ,
    input         rst              ,

    input         conv_start       ,
    input         start            ,
    input [6 : 0] type             ,
    input         stride           ,                            //0Ϊ1���� 1Ϊ2����
    
    input  [AXI_ADDR_WIDTH-1 : 0]       base_addr,              //д�ڴ����ʼ����ַ
    input  [LEN_WIDTH : 0]              out_col_channel_num,    //m_data_len   ���һ�е�����
    input  [ROW_WIDTH : 0]              row_num,
    input  [CALULATE_CNT_WIDTH : 0]     calculate_cout_num,     //���ͨ���������=���ͨ����/������ж�    


    //��ǰģ���������
    //CHA_PAR_OUT�����
    input  [DATA_WIDTH-1 : 0]         s_data  ,
    input                             s_valid,
    input                             s_last ,
    output                            s_req,                  //req���������������������һ�� ready�������� �������һ�� �������һ��������   


    //fifo���¼�ģ���������
    output [DATA_WIDTH-1 : 0]   m_data ,
    output                      m_last ,
    output                      m_valid,
    input                       m_ready, 

    //ping��������
    output [DATA_WIDTH-1 : 0]   ping_s_data    ,
    output                      ping_s_valid  ,
    output                      ping_s_last   ,
    input                       ping_s_req  ,

    //ping��fifo�������
    input  [DATA_WIDTH-1 : 0]   ping_m_data   ,
    input                       ping_m_valid  ,
    input                       ping_m_last   ,
    output                      ping_m_req    ,


    output [DATA_WIDTH-1 : 0]   pang_s_data    ,
    output                      pang_s_valid  ,
    output                      pang_s_last   ,
    input                       pang_s_req    ,


    input  [DATA_WIDTH-1 : 0]   pang_m_data   ,
    input                       pang_m_valid  ,
    input                       pang_m_last   ,
    output                      pang_m_req    ,
   

    //ָ������
    output  [AXI_ADDR_WIDTH-1 : 0]      cmd_addr      ,
    output  [AXI_DATA_WIDTH-1 : 0]      cmd_len       ,
    output                              cmd_valid     ,
    input                               cmd_ready     ,

    output                      calculate_end ,
    input                       calculate_end_receive             
);
// [sim-compat] explicit implicit-net declaration (use-before-decl)
    wire empty;

// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
    localparam IDLE = 4'b0001, WADDR = 4'b0010, RDATA = 4'b0100, WAIT = 4'b1000;
    reg [3 : 0] state, next_state;
    reg [ROW_WIDTH : 0] row_cnt;
    reg [ROW_WIDTH : 0] row_num_r;
    reg [31 : 0] data_addr;
    reg cmd_valid_r;
    reg [LEN_WIDTH : 0] cmd_len_r;
    reg [CALULATE_CNT_WIDTH : 0]  calculate_cout_cnt;
    reg [CALULATE_CNT_WIDTH : 0]  calculate_cout_num_r;
    reg w_ctl;
    reg s_valid_d;
    reg alter_cross;
    reg r_ctl;
    localparam ADDR_WIDTH = $clog2(DATA_DEPTH);
    wire [ADDR_WIDTH : 0] fifo_cnt;
    reg fifo_req;
    wire [DATA_WIDTH-1 : 0] data;
    wire valid = (r_ctl == 1'b0) ? ping_m_valid : pang_m_valid;
    wire last  = (r_ctl == 1'b0) ? ping_m_last : pang_m_last;
    localparam CNT_WIDTH = ((CHA_PAR_OUT / CONV_CHA_PAR_OUT) == 1) ? 1 : $clog2(CHA_PAR_OUT / CONV_CHA_PAR_OUT);
    reg [CNT_WIDTH-1 : 0] conv_cnt;
    reg [DATA_WIDTH-1 : 0] conv_data;
    reg conv_valid;
    reg conv_last;
    reg                  wen;
    reg [DATA_WIDTH : 0] din;
    wire [DATA_WIDTH : 0] dout;
    wire ren = m_valid & m_ready;
    reg calculate_end_r;



    //״̬��
    always @(posedge clk) begin
        if(rst) begin
            state <= IDLE;
        end
        else begin
            state <= next_state;
        end
    end

    always @(*) begin
        case(state)
            IDLE:begin
                if(start) begin
                    next_state = WADDR;
                end
                else begin
                    next_state = IDLE;
                end
            end
            WADDR:begin                                     //����DMA�������  W����д��DMA
                if(cmd_valid & cmd_ready) begin
                    next_state = RDATA;
                end
                else begin
                    next_state = WADDR;
                end
            end
            RDATA:begin                                      //�ӵ�ǰģ�������DMA��д����
                if(m_valid & m_ready & m_last) begin         //FIFO�������һ������ת  ��fifo�źŲ���Ӱ��
                    next_state = WAIT;                      //����״̬������ת  ��FIFOд��ʱ���last��valid������Ӱ��
                end
                else begin
                    next_state = RDATA;
                end
            end
            WAIT:begin
                if(row_cnt == row_num_r) begin
                    next_state = IDLE;
                end
                else begin
                    next_state = WADDR;
                end
            end
            default:begin
                next_state = IDLE;
            end
        endcase
    end


//////////////////////////////////////////////////////���п���////////////////////////////////////////////////////////
    //�п���
    always @(posedge clk ) begin
        if(rst) begin
            row_cnt <= 0;
        end
        else if(state == IDLE) begin
            row_cnt <= 0;
        end
        else if(m_last & m_valid & m_ready) begin
            row_cnt <= row_cnt + 1;
        end
    end

    always @(posedge clk ) begin
        if(start) begin
            if(type[6]) begin
                row_num_r <= row_num[ROW_WIDTH : 1];
            end
            else if(type[5]) begin
                row_num_r <= {row_num, 1'b0};
            end
            else if(type[0] && stride) begin
                row_num_r <= row_num[ROW_WIDTH : 1];
            end
            else begin
                row_num_r <= row_num;
            end 
        end
    end


/////////////////////////////////CMD����///////////////////////////////////////////
    //�ڴ�д��ַ��λ
    always @(posedge clk) begin
        if(start) begin
            data_addr <= base_addr;
        end
        else if(cmd_valid & cmd_ready) begin
            data_addr <= data_addr + out_col_channel_num;
        end
    end
    assign cmd_addr = data_addr;

    always @(posedge clk ) begin
        if(rst) begin
            cmd_valid_r <= 1'b0;
        end
        else if(!empty && (next_state == WADDR)) begin
            cmd_valid_r <= 1'b1;
        end
        else if(cmd_valid & cmd_ready) begin
            cmd_valid_r <= 1'b0;
        end    
    end
    assign cmd_valid = cmd_valid_r;

    always @(posedge clk ) begin
        if(start)begin
            cmd_len_r <= out_col_channel_num;
        end
    end
    assign cmd_len = cmd_len_r;


///////////////////////////////�����ź����////////////////////////////////////////
    //�����������
    always @(posedge clk ) begin
        if(rst) begin
            calculate_cout_cnt <= 0;
        end
        // else if(start) begin
        //     calculate_cout_cnt <= 0;
        // end
        else if(s_last & s_valid) begin
            if(calculate_cout_cnt == calculate_cout_num_r - 1) begin
                calculate_cout_cnt <= 0;
            end
            else begin
                calculate_cout_cnt <= calculate_cout_cnt + 1;
            end
        end
    end

    always @(posedge clk ) begin
        if(start)begin
            calculate_cout_num_r <= calculate_cout_num;
        end
    end




    





////////////////////////////////////////////���ϼ����뵽ƹ��BUF/////////////////////////////////////////////////////////////////
    //д������
    always @(posedge clk ) begin
        if(rst) begin
            w_ctl <= 1'b0;
        end
        else if(s_last && s_valid && (calculate_cout_cnt == calculate_cout_num_r - 1)) begin
            w_ctl <= !w_ctl;
        end
    end


    //��Ƶ��  Ϊ��ʹvalid����1010���������Ƶ��
    always @(posedge clk) begin
        if(rst)begin
            s_valid_d <= 1'b0;
        end
        else begin
            s_valid_d <= s_valid;
        end
    end

    always @(posedge clk) begin
        if(rst) begin
            alter_cross <= 1'b1;
        end
        else if(stride) begin
            if(s_valid) begin
                if(~s_valid_d) begin
                    alter_cross <= 1'b0;
                end
                else begin
                    alter_cross <= !alter_cross;
                end
            end
        end
        else begin
            alter_cross <= 1'b1;
        end
    end

    

    assign ping_s_data = (w_ctl == 1'b0) ? s_data : 0;
    assign ping_s_valid = (w_ctl == 1'b0) ? s_valid & alter_cross : 1'd0;
    assign ping_s_last  = (w_ctl == 1'b0) ? s_last & ping_s_valid : 1'd0;


    assign pang_s_data = (w_ctl == 1'b1) ? s_data : 0;
    assign pang_s_valid = (w_ctl == 1'b1) ? s_valid & alter_cross : 1'd0;
    assign pang_s_last  = (w_ctl == 1'b1) ? s_last & pang_s_valid : 1'd0;

    // assign s_req = (w_ctl == 1'b0) ? ping_s_req : pang_s_req;
    assign s_req = ping_s_req | pang_s_req;

    // assign ping_s_data = (w_ctl == 1'b0) ? s_data : 0;
    // assign ping_s_valid = (w_ctl == 1'b0) ? s_valid : 1'd0;
    // assign ping_s_last  = (w_ctl == 1'b0) ? s_last & ping_s_valid : 1'd0;


    // assign pang_s_data = (w_ctl == 1'b1) ? s_data : 0;
    // assign pang_s_valid = (w_ctl == 1'b1) ? s_valid : 1'd0;
    // assign pang_s_last  = (w_ctl == 1'b1) ? s_last & pang_s_valid : 1'd0;

    // assign s_req = (w_ctl == 1'b0) ? ping_s_req : pang_s_req;
    


////////////////////////////////////////////��ƹ��BUF���뵽ctl��FIFO/////////////////////////////////////////////////////////////////

    //��������
    always @(posedge clk ) begin
        if(rst) begin
            r_ctl <= 1'b0;
        end
        else if(wen & din[DATA_WIDTH])begin
            r_ctl <= !r_ctl;
        end
    end

    // //�¼����������ź�
    // reg fifo_req;
    // always @(posedge clk ) begin
    //     if(rst)begin
    //         fifo_req <= 1'b0;
    //     end
    //     else if((state == WADDR) && (next_state == RDATA)) begin
    //         fifo_req <= 1'b1;
    //     end
    //     else if(wen) begin    //�����ݽ���������
    //         fifo_req <= 1'b0;
    //     end
    // end

    
    
    // assign ping_m_req = (r_ctl == 1'b0) ? fifo_req && (state == RDATA) : 1'b0;
    // assign pang_m_req = (r_ctl == 1'b1) ? fifo_req && (state == RDATA) : 1'b0;

    // wire [DATA_WIDTH : 0] din;
    // assign din = (r_ctl == 1'b0) ? {ping_m_last, ping_m_data} : {pang_m_last, pang_m_data};
    // wire wen = (r_ctl == 1'b0) ? (ping_m_valid && (state == RDATA)) : (pang_m_valid && (state == RDATA));


    //FIFO��������
    // reg [ADDR_WIDTH-1 : 0] fifo_cnt;
    // always @(posedge clk) begin
    //     if(rst)begin
    //         fifo_cnt <= {ADDR_WIDTH{1'b0}};
    //     end
    //     else if(wen & ~ren)begin
    //         fifo_cnt <= fifo_cnt + 1'b1;
    //     end
    //     else if(~wen & ren)begin
    //         fifo_cnt <= fifo_cnt - 1'b1;
    //     end
    // end

    //�¼����������ź�   ����������ٶ� ���������ǲ���״̬����RDATAԼ��
    always @(posedge clk ) begin
        if(rst)begin
            fifo_req <= 1'b0;
        end
        else if(wen) begin    //�����ݽ���������
            fifo_req <= 1'b0;
        end
        // else if(fifo_cnt < (DATA_DEPTH-2)) begin
        else if(DATA_DEPTH - fifo_cnt >= out_col_channel_num/CHA_PAR_OUT) begin
            fifo_req <= 1'b1;
        end
        // else if(empty) begin
        //     fifo_req <= 1'b1;
        // end
    end
    
    assign ping_m_req = (r_ctl == 1'b0) ? fifo_req : 1'b0;
    assign pang_m_req = (r_ctl == 1'b1) ? fifo_req : 1'b0;




    assign data = (r_ctl == 1'b0) ? ping_m_data : pang_m_data;

    always @(posedge clk) begin
        if(rst) begin
            conv_cnt <= 0;
        end
        else if(conv_start) begin
            if(DATA_WIDTH == CONV_DATA_WIDTH) begin
                conv_cnt <= 0;
            end
            else if(valid) begin
                conv_cnt <= conv_cnt + 1'b1;
            end
        end
        else begin
            conv_cnt <= 0;
        end
    end

    always @(posedge clk) begin
        if(conv_start) begin
           if(DATA_WIDTH == CONV_DATA_WIDTH) begin
                conv_data <= data;
            end
            else if(valid) begin
                conv_data <= {data, conv_data[DATA_WIDTH-1 : CONV_DATA_WIDTH]};
            end 
        end
        else begin
            conv_data <= data;
        end
    end

    always @(posedge clk) begin
        if(rst) begin
            conv_valid <= 1'b0;
        end
        else if(conv_start) begin
            if(conv_cnt == (CHA_PAR_OUT / CONV_CHA_PAR_OUT)-1)begin
                conv_valid <= valid;
            end
            else begin
                conv_valid <= 1'b0;
            end
        end
        else begin
            conv_valid <= valid;
        end
    end

    always @(posedge clk) begin
        conv_last <= last;
    end





    // wire [DATA_WIDTH : 0] din;
    // assign din = {conv_last, conv_data};
    // wire wen = conv_valid;

    always @(posedge clk) begin
        if (rst) begin
            wen <= 1'b0;
        end 
        else begin
            wen <= conv_valid;
        end
    end

    always @(posedge clk) begin
        din <= {conv_last, conv_data};
    end


    // wire [DATA_WIDTH : 0] din;
    // assign din = (r_ctl == 1'b0) ? {ping_m_last, ping_m_data} : {pang_m_last, pang_m_data};
    // wire wen = (r_ctl == 1'b0) ? ping_m_valid : pang_m_valid;








////////////////////////////////////////////��ctl��FIFO������DMA/////////////////////////////////////////////////////////////////

    //��������0�ӳ�ͬ��FIFO ��ΪDMA��ready����һֱ���ߵ�  ��DMAready���͵������Ҫ��ѹrenʹ��ַ�������
    //��������ӳ� ready��ѹ��ʱ�� radd�Ѿ���ȥ�� ��ready�Ƿ�ѹ����һ��raadr ��ʹ��raddr��һ����ַ������û�б�DMA����
    
    sync_fifo  #(
        .DATA_WIDTH(DATA_WIDTH + 1),
        .DATA_DEPTH(DATA_DEPTH)
    ) 
    sync_fifo_inst(
      .clk(clk),      // input wire clk
      .rst(rst),     // input wire rst
      .fifo_cnt(fifo_cnt),
      .din(din),      // input wire [64 : 0] din
      .wr_en(wen),  // input wire wr_en
      .rd_en(ren),  // input wire rd_en
      .dout(dout),    // output wire [64 : 0] dout
      .full(full),    // output wire full
      .empty(empty)   // output wire empty
    );

    assign m_valid = !empty & (state == RDATA);
    assign m_last = dout[DATA_WIDTH] & m_valid;
    assign m_data = dout[DATA_WIDTH-1 : 0];








    ///////////////////////////////////�����ź�/////////////////////////////////////////////////
    // assign calculate_end  = ((state == WAIT) && (next_state == IDLE)) ? 1'b1 : 1'b0;

    always @(posedge clk) begin
        if(rst) begin
            calculate_end_r <= 1'b0;
        end
        else if(calculate_end & calculate_end_receive) begin
            calculate_end_r <= 1'b0;
        end
        else if((state == WAIT) && (next_state == IDLE)) begin
            calculate_end_r <= 1'b1;
        end
    end
    assign calculate_end = calculate_end_r;

endmodule