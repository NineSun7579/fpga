module upsample_ctrl #(
    parameter MAX_IN_ROW = 320,                          //�����IMG���������
              ROW_WIDTH = $clog2(MAX_IN_ROW)
)
(
    input          clk          ,
    input          rst          ,
    input          start        ,

    input [ROW_WIDTH : 0]   row_num  ,



    input          s_valid   ,
    input          s_last    ,
    output         s_req     ,             

    input          calculate_req               //˵������ģ����Խ����µļ������� ���������

);
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
    reg [ROW_WIDTH : 0] row_cnt;
    localparam IDLE = 3'b001, WAIT = 3'b010, CALCULATE = 3'b100;
    reg [2 : 0] state, next_state;
    reg s_req_r;
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
// [sim-compat] declarations hoisted for declaration-before-use (ModelSim)

    //״̬��
    always @(posedge clk) begin
        if(rst) begin
            state <= IDLE;
        end
        else begin
            state <= next_state;
        end
    end

    always @(*) begin
        case(state)
            IDLE:begin
                if(start) begin
                    next_state = WAIT;
                end
                else begin
                    next_state = IDLE;
                end
            end
            WAIT:begin                                            //�ȴ�����׼����ģ��
                if(row_cnt == row_num) begin
                    next_state = IDLE;
                end
                else if(calculate_req) begin
                    next_state = CALCULATE;
                end
                else begin
                    next_state = WAIT;
                end
            end
            CALCULATE:begin                                        //����ģ��
                if(s_valid & s_last) begin               
                    next_state = WAIT;
                end
                else begin
                    next_state = CALCULATE;
                end
            end
            default:begin
                next_state = IDLE;
            end
        endcase
    end


//////////////////////////////��������///////////////////////////////////////
    //��Ӧ������
    always @(posedge clk) begin
        if(state == IDLE) begin
            row_cnt <= 0;
        end
        else if((state == CALCULATE) && (next_state == WAIT))begin
            row_cnt <= row_cnt + 1'b1;
        end
    end




//////////////////////////////�������///////////////////////////////////////
    always @(posedge clk) begin
        if(rst) begin
            s_req_r <= 1'b0;
        end
        if((state == WAIT) && (next_state == CALCULATE)) begin
            s_req_r <= 1'b1;
        end
        else if(s_req_r & s_valid)begin
            s_req_r <= 1'b0;
        end
    end
    assign s_req = s_req_r;



endmodule