module upsample_in_buf #(
    parameter CHA_PAR_IN = 16,                          //����ͨ�����ж�
              //ͼƬͨ��//
              CHA_IMG_IN = 128,                          //�����IMG�����ͨ����
              MAX_IN_CALULATE_NUM = (CHA_IMG_IN / CHA_PAR_IN),          //����ͨ���������=����ͨ����/���벢�ж� 
              IN_CALULATE_CNT_WIDTH = $clog2(MAX_IN_CALULATE_NUM),   


              INT = 8,
              DATA_WIDTH = CHA_PAR_IN * INT,            //���ݴ���λ��    ���벢�ж� * INT8
              DATA_DEPTH = 160,                         //�������  ������ W*channal/���ж�  RAM������Ӧ�ô���һ�����������ֽڸ���
              ADDR_WIDTH = $clog2(DATA_DEPTH),          //��ַλ��
              READ_DELAY = 2                            //������������Ҫ���ӳ�
              
)
(
    input          clk,
    input          rst,


    //һ�ζ�ȡ���жȸ��ֽ��� ��Ҫ��ȡ���ٴβ��ܰ�һ�����ݶ��� read_num = col * channel / CHA_PAR_IN
    input  [ADDR_WIDTH : 0]   read_num, 
    //����ͨ���������
    input  [IN_CALULATE_CNT_WIDTH : 0] calculate_cin_num,

    //��ǰģ���������
    input  [DATA_WIDTH-1 : 0]   s_data,
    input                       s_valid,
    input                       s_last,
    output                      s_ready,


    //�¼�ģ���������
    input                       m_req,
    output [DATA_WIDTH-1 : 0]   m_data,
    output                      m_valid,
    output                      m_last
                                          
);
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
    reg ren;
    reg [ADDR_WIDTH-1 : 0] raddr_0, raddr_1;
    reg double_row;
    localparam IDLE = 4'b0001, WRITE = 4'b0010, WAIT = 4'b0100, READ = 4'b1000;
    reg [3 : 0] state, next_state;
    reg [IN_CALULATE_CNT_WIDTH : 0] calculate_cin_cnt;
    wire wen = s_valid & s_ready;
    reg [ADDR_WIDTH-1 : 0] waddr;
    reg s_ready_r;
    wire ren_0, ren_1;
    reg ren_ctl;
    wire r_valid_0 = ren_0;
    wire r_valid_1 = ren_1;
    reg r_last;                         
    reg [READ_DELAY-1 : 0] m_valid_d_0, m_valid_d_1, m_last_d; 
    wire [DATA_WIDTH-1 : 0]  r_data_0, r_data_1;
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
// [sim-compat] declarations hoisted for declaration-before-use (ModelSim)


    //״̬��
    always @(posedge clk) begin
        if(rst) begin
            state <= IDLE;
        end
        else begin
            state <= next_state;
        end
    end

    always @(*) begin
        case(state)
            IDLE: begin
                next_state = WRITE;
            end
            WRITE:begin
                if(s_valid & s_ready & s_last) begin
                    next_state = WAIT;
                end
                else begin
                    next_state = WRITE;
                end
            end
            WAIT:begin
                if(m_req) begin
                    next_state = READ;
                end
                else begin
                    next_state = WAIT;
                end
            end
            READ:begin
                if(m_last & m_valid & double_row) begin
                    next_state = IDLE;
                end
                else if(m_last & m_valid & !double_row) begin
                    next_state = WAIT;
                end
                else begin
                    next_state = READ;
                end
            end
            default:begin
                next_state = IDLE;
            end
        endcase
    end



    /////////////////////////////////�������/////////////////////////////////
    //����������
    always @(posedge clk) begin
        if(rst) begin
            calculate_cin_cnt <= 0;
        end
        else if(ren) begin
            if(calculate_cin_cnt == (calculate_cin_num - 1))begin
                calculate_cin_cnt <= 0;
            end
            else begin
                calculate_cin_cnt <= calculate_cin_cnt + 1'b1;
            end
        end
        else begin
            calculate_cin_cnt <= 0;
        end
    end

    /////////////////////////////////////////////////////////////////////дʱ��////////////////////////////////////////////////////////////////
    //дʱ�� 0 

    always @(posedge clk) begin                                        
        if(rst) begin
            waddr <= 0;
        end                                                                                                                                          
        else if(state == IDLE) begin
            waddr <= 0;
        end
        else if(wen) begin
            waddr <= waddr + 1'b1;
        end                                   
    end

    always @(posedge clk) begin
        if(rst) begin
            s_ready_r <= 1'b0;
        end
        else if((state == IDLE) && (next_state == WRITE)) begin
            s_ready_r <= 1'b1;
        end
        else if(s_valid & s_ready & s_last) begin
            s_ready_r <= 1'b0;
        end
    end
    assign s_ready = s_ready_r;



                


   /////////////////////////////////////////////////////////////////////��ʱ��////////////////////////////////////////////////////////////////
    //��ʱ��                                     
    always @(posedge clk) begin
        if(rst) begin
            ren <= 1'b0;
        end
        else if((state == WAIT) && (next_state == READ)) begin
            ren <= 1'b1;
        end
        else if(raddr_0 == read_num) begin          // [ups-fix] was raddr_1==read_num-1: dropped the final RAM1 word; raddr_0 leads raddr_1 by one read -> terminates after exactly 2*read_num reads
            ren <= 1'b0;
        end
    end
    
    //ƹ��ʱ��
    always @(posedge clk) begin
        if(rst) begin
            ren_ctl <= 1'b0;
        end
        else if(state == READ) begin
            if(calculate_cin_cnt == (calculate_cin_num - 1)) begin
                ren_ctl <= !ren_ctl;
            end
        end
        else begin
            ren_ctl <= 1'b0;
        end
    end
    assign ren_0 = ren & !ren_ctl;
    assign ren_1 = ren &  ren_ctl;

    always @(posedge clk) begin                                        
        if(rst) begin
            raddr_0 <= 0;
        end                                                                                                                                          
        else if(state == READ) begin
            if(ren_0) begin
                raddr_0 <= raddr_0 + 1'b1;
            end
        end
        else begin
            raddr_0 <= 0;
        end                                   
    end
    //1
    always @(posedge clk) begin                                        
        if(rst) begin
            raddr_1 <= 0;
        end                                                                                                                                          
        else if(state == READ) begin
            if(ren_1) begin
                raddr_1 <= raddr_1 + 1'b1;
            end
        end
        else begin
            raddr_1 <= 0;
        end                                   
    end


    always @(posedge clk) begin
        if(rst) begin
            r_last <= 1'b0;
        end
        else if(raddr_1 == read_num - 1) begin      // [ups-fix] was read_num-2: m_last now aligns with the final word
            r_last <= 1'b1;
        end
        else begin
            r_last <= 1'b0;
        end
    end

    //�б���
    always @(posedge clk) begin
        if(rst) begin
            double_row <= 1'b0;
        end
        else if(m_last & m_valid) begin
            double_row <= ~double_row;
        end
    end


    //�������ӳ�  �����´���ȫ����spram���ӳ��йأ�
    always @(posedge clk ) begin
        if(rst) begin
            m_valid_d_0 <= 0;
            m_valid_d_1 <= 0;
            m_last_d <= 0;
        end
        else begin
            m_valid_d_0  <= {m_valid_d_0[READ_DELAY-1 : 0] , r_valid_0};
            m_valid_d_1  <= {m_valid_d_1[READ_DELAY-1 : 0] , r_valid_1};
            m_last_d <= {m_last_d[READ_DELAY-1 : 0] , r_last};
        end
    end

    //���ʱ��
    assign m_valid = m_valid_d_0[READ_DELAY-1] | m_valid_d_1[READ_DELAY-1];
    assign m_last = m_last_d[READ_DELAY-1];

    assign m_data = m_valid_d_0[READ_DELAY-1] ? r_data_0 : r_data_1;

    spram #(.DP(DATA_DEPTH),    //�洢��Ԫ���
            .DW(DATA_WIDTH),    //����λ��
            .PIPE(READ_DELAY)  
    ) sparm_inst_0
    (
        .clk   (clk   ),
        .wdata (s_data ),
        .wen   (wen   ),
        .waddr (waddr ),
        .ren   (ren_0   ),
        .raddr (raddr_0 ),
        .rdata (r_data_0 )
    );


    spram #(.DP(DATA_DEPTH),    //�洢��Ԫ���
            .DW(DATA_WIDTH),    //����λ��
            .PIPE(READ_DELAY)  
    ) sparm_inst_1
    (
        .clk   (clk   ),
        .wdata (s_data ),
        .wen   (wen   ),
        .waddr (waddr ),
        .ren   (ren_1   ),
        .raddr (raddr_1 ),
        .rdata (r_data_1 )
    );




endmodule