module conv_conv #(
    parameter CHA_PAR_IN = 16,                           //����ͨ�����ж�
              CHA_PAR_OUT = 8,                           //���ͨ�����ж�
              INT = 8,                                   //ÿ������λ��
              DATA_WIDTH = CHA_PAR_IN * INT,             //���ݴ���λ��    ���벢�ж� * INT8
              OUT_DATA_WIDTH = 2*INT + 4 + $clog2(CHA_PAR_IN),
              MUL_DELAY = 4                              //conv�ĳ˷����ӳ�
)
(
    input          clk         ,
    input          rst         ,

    input          start       ,
    input          type        ,            //type = 0 conv33;   type = 1 conv11

    //Ȩ�صĴ��䣨9���� ���벢�ж�λ����
    input [DATA_WIDTH-1 : 0] weight_0    ,
    input [DATA_WIDTH-1 : 0] weight_1    ,
    input [DATA_WIDTH-1 : 0] weight_2    ,
    input [DATA_WIDTH-1 : 0] weight_3    ,
    input [DATA_WIDTH-1 : 0] weight_4    ,
    input [DATA_WIDTH-1 : 0] weight_5    ,
    input [DATA_WIDTH-1 : 0] weight_6    ,
    input [DATA_WIDTH-1 : 0] weight_7    ,
    input [DATA_WIDTH-1 : 0] weight_8    ,
    input                       weight_valid,
    input                       weight_last ,

    //img���ݵĴ���(3��)
    input [DATA_WIDTH-1 : 0] s_data_0      ,
    input [DATA_WIDTH-1 : 0] s_data_1      ,
    input [DATA_WIDTH-1 : 0] s_data_2      ,
    input                       s_valid  ,
    input                       s_last   ,

    

    output [CHA_PAR_OUT * OUT_DATA_WIDTH-1 : 0]  m_data   ,
    output                                       m_valid,
    output                                       m_last 

    // output         mul_last                 //�˷������ܵ����һ������
);
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
    reg [DATA_WIDTH-1 : 0] data_r[2 : 0][2 : 0];
    reg [DATA_WIDTH-1 : 0] data[2 : 0][2 : 0];
    reg [$clog2(CHA_PAR_OUT)-1 : 0] kernel_cnt;
    reg w_ctl;
    reg [DATA_WIDTH-1 : 0] weight_mem_ping[CHA_PAR_OUT-1 : 0][2 : 0][2 : 0];
    reg [DATA_WIDTH-1 : 0] weight_mem_pang[CHA_PAR_OUT-1 : 0][2 : 0][2 : 0];
    wire mul_last;
    reg r_ctl;
    reg [INT-1 : 0] weight_data[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0][0 : 2][0 : 2];
    wire [2*INT-1 : 0] mul[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0][0 : 2][0 : 2];
    reg [2*INT+1 : 0] add_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    reg [2*INT+1 : 0] add_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    reg [2*INT+1 : 0] add_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    reg [OUT_DATA_WIDTH-1 : 0] add_cin[0 : $clog2(CHA_PAR_IN)-1][0 : (CHA_PAR_IN >> 1)-1][0 : CHA_PAR_OUT-1];
    localparam DELAY = 1 + 3 + MUL_DELAY + 2 + $clog2(CHA_PAR_IN);
    reg [DELAY-1-2 : 0] data_valid_d, data_last_d; 
    reg [1 : 0] delay_cnt;
    reg [2*INT+3 : 0] add_33[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];     //3*3�������+����   i��ͨ�� j�Ǻ�  
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)


////////////////////////////////////////////////////��������img�Ĵ���/////////////////////////////////////////////////////////////////
    //ȡ�������ݵ�9������� ��ÿ���������벢��ͨ������ͨ������
    always @(posedge clk) begin
        //��0�е�������������data_0�ǵ���������
        data_r[0][2] <= s_data_0         ;
        data_r[0][1] <= data_r[0][2]     ;
        data_r[0][0] <= data_r[0][1]     ;

        //��1�е�������������data_1�ǵ���������
        data_r[1][2] <= s_data_1         ;
        data_r[1][1] <= data_r[1][2]     ;
        data_r[1][0] <= data_r[1][1]     ;

        //��2�е�������������data_2�ǵ���������
        data_r[2][2] <= s_data_2         ;
        data_r[2][1] <= data_r[2][2]     ;
        data_r[2][0] <= data_r[2][1]     ;
    end

    always @(posedge clk) begin
        data[0][2] <= data_r[0][2]; 
        data[0][1] <= data_r[0][1];
        data[0][0] <= data_r[0][0];

        data[1][2] <= data_r[1][2]; 
        data[1][1] <= data_r[1][1];
        data[1][0] <= data_r[1][0];

        data[2][2] <= data_r[2][2]; 
        data[2][1] <= data_r[2][1];
        data[2][0] <= data_r[2][0];
    end

////////////////////////////////////////////////////����Ÿ�weight�Ĵ���/////////////////////////////////////////////////////////////////
    //��conv33_weight�е�һ�� ����ָ���м�����������ʹ��
    always @(posedge clk) begin
        if(rst) begin
            kernel_cnt <= 0;
        end
        else if(weight_valid) begin
            kernel_cnt <= kernel_cnt + 1;
        end
        else begin
            kernel_cnt <= 0;
        end
    end

    ////////ƹ�Ҵ���//////
    //дƹ��
    always @(posedge clk) begin
        if(rst) begin
            w_ctl <= 1'b0;
        end
        else if(start) begin
            w_ctl <= 1'b0;
        end
        else if(weight_last) begin
            w_ctl <= !w_ctl;
        end
    end

    //��ÿ���������벢��ͨ������ͨ������  �������ͨ������          ��      ��

    always @(posedge clk ) begin
        if(weight_valid)begin

            if(w_ctl == 1'b0) begin
                weight_mem_ping[kernel_cnt][0][0] <= weight_0;
                weight_mem_ping[kernel_cnt][0][1] <= weight_1;
                weight_mem_ping[kernel_cnt][0][2] <= weight_2;

                weight_mem_ping[kernel_cnt][1][0] <= weight_3;
                weight_mem_ping[kernel_cnt][1][1] <= weight_4;
                weight_mem_ping[kernel_cnt][1][2] <= weight_5;

                weight_mem_ping[kernel_cnt][2][0] <= weight_6;
                weight_mem_ping[kernel_cnt][2][1] <= weight_7;
                weight_mem_ping[kernel_cnt][2][2] <= weight_8;
            end       
            else begin
                weight_mem_pang[kernel_cnt][0][0] <= weight_0;
                weight_mem_pang[kernel_cnt][0][1] <= weight_1;
                weight_mem_pang[kernel_cnt][0][2] <= weight_2;

                weight_mem_pang[kernel_cnt][1][0] <= weight_3;
                weight_mem_pang[kernel_cnt][1][1] <= weight_4;
                weight_mem_pang[kernel_cnt][1][2] <= weight_5;

                weight_mem_pang[kernel_cnt][2][0] <= weight_6;
                weight_mem_pang[kernel_cnt][2][1] <= weight_7;
                weight_mem_pang[kernel_cnt][2][2] <= weight_8;
            end

        end
    end

    ////////ƹ�Ҵ���//////
    //��ƹ��
    always @(posedge clk) begin
        if(rst) begin
            r_ctl <= 1'b0;
        end
        else if(start) begin
            r_ctl <= 1'b0;
        end
        else if(mul_last) begin
            r_ctl <= !r_ctl;
        end
    end

    /////////weight�Ķ���////////      ����ͨ�����ж�      ���ͨ�����ж�      ��     ��
    // wire [INT-1 : 0] weight_data_0_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_0_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_0_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_1_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_1_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_1_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_2_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_2_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [INT-1 : 0] weight_data_2_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    
    genvar i, j, l;
    generate
        for(i = 0; i < CHA_PAR_IN; i = i + 1) begin: WIGHT_I
            for(j = 0; j < CHA_PAR_OUT; j = j + 1) begin: WIGHT_J
                always @(posedge clk) begin
                    weight_data[i][j][0][0] <= (r_ctl == 1'b0) ? weight_mem_ping[j][0][0][i*INT +: INT] : weight_mem_pang[j][0][0][i*INT +: INT];
                    weight_data[i][j][0][1] <= (r_ctl == 1'b0) ? weight_mem_ping[j][0][1][i*INT +: INT] : weight_mem_pang[j][0][1][i*INT +: INT];
                    weight_data[i][j][0][2] <= (r_ctl == 1'b0) ? weight_mem_ping[j][0][2][i*INT +: INT] : weight_mem_pang[j][0][2][i*INT +: INT];

                    weight_data[i][j][1][0] <= (r_ctl == 1'b0) ? weight_mem_ping[j][1][0][i*INT +: INT] : weight_mem_pang[j][1][0][i*INT +: INT];
                    weight_data[i][j][1][1] <= (r_ctl == 1'b0) ? weight_mem_ping[j][1][1][i*INT +: INT] : weight_mem_pang[j][1][1][i*INT +: INT];
                    weight_data[i][j][1][2] <= (r_ctl == 1'b0) ? weight_mem_ping[j][1][2][i*INT +: INT] : weight_mem_pang[j][1][2][i*INT +: INT];

                    weight_data[i][j][2][0] <= (r_ctl == 1'b0) ? weight_mem_ping[j][2][0][i*INT +: INT] : weight_mem_pang[j][2][0][i*INT +: INT];
                    weight_data[i][j][2][1] <= (r_ctl == 1'b0) ? weight_mem_ping[j][2][1][i*INT +: INT] : weight_mem_pang[j][2][1][i*INT +: INT];
                    weight_data[i][j][2][2] <= (r_ctl == 1'b0) ? weight_mem_ping[j][2][2][i*INT +: INT] : weight_mem_pang[j][2][2][i*INT +: INT];
                end
            end
        end
    endgenerate

    




/////////////////////////////////// �˷���� //////////////////////////////////////////////////////////
    //9��˷�  CIN * COUT���    4�����ڳ����
    //                      ����ͨ�����ж�      ���ͨ�����ж�      ��     ��
    // wire [2*INT-1 : 0] mul_0_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_0_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_0_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_1_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_1_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_1_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_2_0[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_2_1[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    // wire [2*INT-1 : 0] mul_2_2[CHA_PAR_IN-1 : 0][CHA_PAR_OUT-1 : 0];
    generate
        for(i = 0; i < CHA_PAR_IN; i = i + 1) begin
            for(j = 0; j < CHA_PAR_OUT/2; j = j + 1) begin
                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_0_0(
                    .clk(clk),
                    .a(weight_data[i][j*2][0][0]  )  ,
                    .b(weight_data[i][j*2+1][0][0])  ,
                    .c(data[0][0][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][0][0]),
                    .b_c(mul[i][j*2+1][0][0])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_0_1(
                    .clk(clk),
                    .a(weight_data[i][j*2][0][1]  )  ,
                    .b(weight_data[i][j*2+1][0][1])  ,
                    .c(data[0][1][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][0][1]),
                    .b_c(mul[i][j*2+1][0][1])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_0_2(
                    .clk(clk),
                    .a(weight_data[i][j*2][0][2]  )  ,
                    .b(weight_data[i][j*2+1][0][2])  ,
                    .c(data[0][2][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][0][2]),
                    .b_c(mul[i][j*2+1][0][2])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_1_0(
                    .clk(clk),
                    .a(weight_data[i][j*2][1][0]  )  ,
                    .b(weight_data[i][j*2+1][1][0])  ,
                    .c(data[1][0][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][1][0]),
                    .b_c(mul[i][j*2+1][1][0])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_1_1(
                    .clk(clk),
                    .a(weight_data[i][j*2][1][1]  )  ,
                    .b(weight_data[i][j*2+1][1][1])  ,
                    .c(data[1][1][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][1][1]),
                    .b_c(mul[i][j*2+1][1][1])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_1_2(
                    .clk(clk),
                    .a(weight_data[i][j*2][1][2]  )  ,
                    .b(weight_data[i][j*2+1][1][2])  ,
                    .c(data[1][2][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][1][2]),
                    .b_c(mul[i][j*2+1][1][2])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_2_0(
                    .clk(clk),
                    .a(weight_data[i][j*2][2][0]  )  ,
                    .b(weight_data[i][j*2+1][2][0])  ,
                    .c(data[2][0][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][2][0]),
                    .b_c(mul[i][j*2+1][2][0])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_2_1(
                    .clk(clk),
                    .a(weight_data[i][j*2][2][1]  )  ,
                    .b(weight_data[i][j*2+1][2][1])  ,
                    .c(data[2][1][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][2][1]),
                    .b_c(mul[i][j*2+1][2][1])    
                );


                conv_mul_E2 #(
                    .INT(INT),
                    .MUL_DELAY(MUL_DELAY)
                )
                conv_mul_inst_2_2(
                    .clk(clk),
                    .a(weight_data[i][j*2][2][2]  )  ,
                    .b(weight_data[i][j*2+1][2][2])  ,
                    .c(data[2][2][i*INT +: INT])  ,
                    .a_c(mul[i][j*2][2][2]),
                    .b_c(mul[i][j*2+1][2][2])    
                );
 
            end
        end
    endgenerate

/////////////////////////////////// �ӷ���� //////////////////////////////////////////////////////////
    //9�����    ///////////2�������///////////    ///////////��4��λ��///////
    generate
        for(i = 0; i < CHA_PAR_IN; i = i+1) begin: ADD_PIPE_0_I
            for(j = 0; j < CHA_PAR_OUT; j = j+1) begin: ADD_PIPE_0_J
                always @(posedge clk ) begin
                    if(type == 1'b0) begin
                        //һ��
                        add_0[i][j] <= $signed(mul[i][j][0][0]) + $signed(mul[i][j][0][1]) + $signed(mul[i][j][0][2]);
                        add_1[i][j] <= $signed(mul[i][j][1][0]) + $signed(mul[i][j][1][1]) + $signed(mul[i][j][1][2]);
                        add_2[i][j] <= $signed(mul[i][j][2][0]) + $signed(mul[i][j][2][1]) + $signed(mul[i][j][2][2]);
                        //����
                        add_33[i][j] <= $signed(add_0[i][j]) + $signed(add_1[i][j]) + $signed(add_2[i][j]);  
                    end
                    // else begin
                    //     //һ��
                    //     add_33[i][j][0] <= $signed(mul[i][j][0][0]);  
                    //     add_33[i][j][1] <= $signed(mul[i][j][0][1]); 
                    //     add_33[i][j][2] <= $signed(mul[i][j][0][2]); 
                    //     add_33[i][j][3] <= $signed(mul[i][j][1][0]); 
                    //     add_33[i][j][4] <= $signed(mul[i][j][1][1]); 
                    //     add_33[i][j][5] <= $signed(mul[i][j][1][2]); 
                    //     add_33[i][j][6] <= $signed(mul[i][j][2][0]); 
                    //     add_33[i][j][7] <= $signed(mul[i][j][2][1]); 
                    //     add_33[i][j][8] <= $signed(mul[i][j][2][2]);
                    // end
                     
                end
            end
        end
    endgenerate

    // //ÿ���˵� ����ͨ�������    ///////////$clog2(CHA_PAR_IN)�������///////////
    // generate
    //     //�˵ı��
    //     for(genvar j = 0; j < CHA_PAR_OUT; j = j+1) begin: KERNEL
    //         //�㼶
    //         for(genvar l = 0; l < $clog2(CHA_PAR_IN); l = l+1) begin: ADD_LAYER
    //         //�㼶��ͨ�����
    //             for(genvar i = 0; i < (CHA_PAR_IN >> (l+1)); i = i+1) begin: ADD_LAYER_CIN

    //                 //      �ӷ����λ��                   �㼶                      ͨ����                      ����                            
    //                 reg [2*INT+4 + l : 0] add_cin[$clog2(CHA_PAR_IN)-1 : 0][(CHA_PAR_IN >> (l+1)) -1 : 0][CHA_PAR_OUT-1 : 0];
    //                 if(l == 0) begin       //��һ�㼶����ǰһ����+��
    //                     always @(posedge clk) begin
    //                         add_cin[l][i][j][2*INT+4+l : 0] <= $signed(add_33[i*2][j]) + $signed(add_33[i*2+1][j]); 
    //                     end
    //                 end
    //                 else begin             //����㼶����ǰһ����+��
    //                     always @(posedge clk) begin
    //                         add_cin[l][i][j][2*INT+4+l : 0] <= $signed(add_cin[l-1][i*2][j]) + $signed(add_cin[l-1][i*2+1][j]);
    //                     end
    //                 end
                    
    //             end
    //         end
    //     end
    // endgenerate

    ///////ÿ���˵� ����ͨ������� /////   ///////////$clog2(CHA_PAR_IN)�������/////////// 
    //                                        �㼶                      ͨ��                   ����         
    generate
        //�˵ı��
        for(j = 0; j < CHA_PAR_OUT; j = j+1) begin: KERNEL
            //�㼶
            for(l = 0; l < $clog2(CHA_PAR_IN); l = l+1) begin: LAYER
            //�㼶��ͨ�����
                for(i = 0; i < (CHA_PAR_IN >> (l+1)); i = i+1) begin: ADD_CIN
                    
                    if(l == 0) begin
                        always @(posedge clk) begin
                            if(type == 1'b0) begin
                                add_cin[l][i][j] <= $signed(add_33[i*2][j]) + $signed(add_33[i*2+1][j]); 
                            end
                            else begin
                                add_cin[l][i][j] <= $signed(mul[i*2][j][1][1]) + $signed(mul[i*2+1][j][1][1]);
                            end
                        end
                    end
                    else begin
                        always @(posedge clk) begin
                            add_cin[l][i][j] <= $signed(add_cin[l-1][i*2][j]) + $signed(add_cin[l-1][i*2+1][j]);
                        end
                    end


                end
            end
        end
    endgenerate



    
/////////////////////////////////// ��������� //////////////////////////////////////////////////////////              
    //��������
    generate
        for(j = 0; j < CHA_PAR_OUT; j = j+1) begin: OUT_PUT
                                                                    //        ���һ�㼶     ��1��ͨ��     �ڼ�����
                assign m_data[j*OUT_DATA_WIDTH +: OUT_DATA_WIDTH] = add_cin[$clog2(CHA_PAR_IN)-1][0][j]; 
        end
    endgenerate              
    
    // //��д��8��������ж�  �����
    // assign m_data_0 = m_data[0];
    // assign m_data_1 = m_data[1];
    // assign m_data_2 = m_data[2];
    // assign m_data_3 = m_data[3];
    // assign m_data_4 = m_data[4];
    // assign m_data_5 = m_data[5];
    // assign m_data_6 = m_data[6];
    // assign m_data_7 = m_data[7];

/////////////////////////////////// �����ź� //////////////////////////////////////////////////////////
    //�������ӳ�  �����´��������������ӳ��йأ�  //1�ĵ����ݽ����ӳ�/weight�㲥�ӳ� + 3�������ӳ� + 4�ĳ˷����ӳ� + 2��3*3��ӷ��ӳ� + $clog2(CHA_PAR_IN)�����벢��ͨ������ӳ�
    always @(posedge clk ) begin
        if(rst) begin
            data_valid_d <= 0;
            data_last_d <= 0;
        end
        else begin
            data_valid_d <= {data_valid_d[DELAY-2-2 : 0], s_valid};
            data_last_d  <= {data_last_d[DELAY-2-2 : 0] , s_last};
        end
    end

    //һ�������һ������ʹ�� Ҳ����data[0][2] <= data_0��һ�ľ�ʹ����  //���ĵ� 5.12
    assign mul_last = data_last_d[0];
    
    //���valid�Ľ�����̫���Ҫ��������3Ҫ��¼2 �����ӳٵ�valid�͸ս�����valid�غ���valid
    // reg [1 : 0] delay_cnt_33;
    // always @(posedge clk) begin
    //     if(rst) begin
    //         delay_cnt_33 <= 0;
    //     end
    //     else if(data_last_d[(DELAY-2)-1]) begin
    //         delay_cnt_33 <= 0;
    //     end
    //     else if(delay_cnt_33 == 2) begin
    //         delay_cnt_33 <= delay_cnt_33;
    //     end
    //     else if(data_valid_d[(DELAY-2)-1]) begin
    //         delay_cnt_33 <= delay_cnt_33 + 1;
    //     end
    // end


    always @(posedge clk) begin
        if(rst) begin
            delay_cnt <= 0;
        end
        else if((type && data_last_d[(DELAY-2)-1-2]) || (!type && data_last_d[(DELAY-2)-1])) begin
            delay_cnt <= 0;
        end
        else if(delay_cnt == 2) begin
            delay_cnt <= delay_cnt;
        end
        else if((type && data_valid_d[(DELAY-2)-1-2]) || (!type && data_valid_d[(DELAY-2)-1])) begin
            delay_cnt <= delay_cnt + 1;
        end
    end


    //��������ź����   ���ĵ��н��ͣ�
    //3�������ӳ� + 4�ĳ˷����ӳ� + 2��3*3��ӷ��ӳ� + $clog2(CHA_PAR_IN)�����벢��ͨ������ӳ�     (1*1û��2��3*3����ӷ��ӳ�)
    // assign m_valid = type ? data_valid_d[DELAY-1-2] & data_valid_d[(DELAY-2)-1-2] : data_valid_d[DELAY-1] & data_valid_d[(DELAY-2)-1];

    assign m_valid = type ? data_valid_d[(DELAY-2)-1-2] && (delay_cnt == 2) : data_valid_d[(DELAY-2)-1] && (delay_cnt == 2);
    //1�������ӳ� + 4�ĳ˷����ӳ� + 2��3*3��ӷ��ӳ� + $clog2(CHA_PAR_IN)�����벢��ͨ������ӳ�     (1*1û��2��3*3����ӷ��ӳ�)
    assign m_last  = type ? data_last_d[(DELAY-2)-1-2] : data_last_d[(DELAY-2)-1];

endmodule



