module focus_in_buf_ctrl #(
    parameter AXI_DATA_WIDTH = 32,
              AXI_ADDR_WIDTH = 32,
    parameter CHA_PAR_IN = 16,              //����ͨ�����ж�
              INT = 8,                        //ÿ������λ��
              DATA_WIDTH = CHA_PAR_IN * INT,  //���ݴ���λ��    ���ж� * INT8
              MAX_IN_LEN = 5120,            //��ģ�������ܵ�����ֽ���  Ҳ����һ��*ͨ�����ֽ���
              LEN_WIDTH = $clog2(MAX_IN_LEN),
              MAX_IN_ROW = 640,             //�����IMG���������
              ROW_WIDTH = $clog2(MAX_IN_ROW),
              READ_DELAY = 1               //������������Ҫ���ӳ�
              
)
(
    input          clk              ,
    input          rst              ,

    input                       start         ,//��ʼ�ź�
    input  [AXI_DATA_WIDTH-1 : 0]        base_addr     ,//��ȡ�ڴ����ʼ����ַ
    input  [LEN_WIDTH : 0]               in_col_channel_num ,//������Ҫ��ȡһ�е����ֽ��� in_col_channel_num  = col * channel
    input  [ROW_WIDTH : 0]               row_num       ,//��������  ������һλ����Ϊ�������������ֵ��û��-1��

    input  [DATA_WIDTH-1 : 0]   s_data        ,//��������
    input                       s_valid       ,
    input                       s_last        ,
    output                      s_ready       ,

    input                       m_req         ,//���¼���������
    output [DATA_WIDTH-1 : 0]   m_data        ,
    output                      m_valid       ,
    output                      m_last        ,

    output [DATA_WIDTH-1 : 0]   ping_s_data   ,//ping����
    output                      ping_s_valid  ,
    output                      ping_s_last   ,
    input                       ping_s_ready  ,

    output                      ping_m_req    ,
    input  [DATA_WIDTH-1 : 0]   ping_m_data   ,
    input                       ping_m_valid  ,
    input                       ping_m_last   ,


    output [DATA_WIDTH-1 : 0]   pang_s_data   ,//pang����
    output                      pang_s_valid  ,
    output                      pang_s_last   ,
    input                       pang_s_ready  ,

    output                      pang_m_req    ,
    input  [DATA_WIDTH-1 : 0]   pang_m_data   ,
    input                       pang_m_valid  ,
    input                       pang_m_last   ,

    output [AXI_ADDR_WIDTH-1 : 0]    cmd_addr      ,//ָ������
    output [AXI_DATA_WIDTH-1 : 0]    cmd_len       ,
    output                           cmd_valid     ,
    input                            cmd_ready            
);

    //״̬��
    localparam IDLE = 4'b0001, WADDR = 4'b0010, WDATA = 4'b0100, WAIT = 4'b1000;
    reg [3 : 0] state, next_state;
    always @(posedge clk) begin
        if(rst) begin
            state <= IDLE;
        end
        else begin
            state <= next_state;
        end
    end

    always @(*) begin
        case(state)
            IDLE:begin
                if(start) begin
                    next_state = WADDR;
                end
                else begin
                    next_state = IDLE;
                end
            end
            WADDR:begin                                     //����DMA�������  W����д��DMA
                if(cmd_valid & cmd_ready) begin
                    next_state = WDATA;
                end
                else begin
                    next_state = WADDR;
                end
            end
            WDATA:begin                                     //��DMA������ݳ���д�뵱ǰģ��
                if(s_last & s_valid & s_ready) begin
                    next_state = WAIT;
                end
                else begin
                    next_state = WDATA;
                end
            end
            WAIT:begin
                if(row_cnt == row_num) begin
                    next_state = IDLE;
                end
                else begin
                    next_state = WADDR;
                end
            end
            default:begin
                next_state = IDLE;
            end
        endcase
    end


    //�п���
    reg [ROW_WIDTH : 0] row_cnt;
    always @(posedge clk ) begin
        if(rst) begin
            row_cnt <= 0;
        end
        else if(state == IDLE) begin
            row_cnt <= 0;
        end
        else if(s_last & s_valid & s_ready) begin
            row_cnt <= row_cnt + 1;
        end
    end


    //�ڴ��ȡ��ַ����
    reg [31 : 0] data_addr;
    always @(posedge clk) begin
        if(start) begin
            data_addr <= base_addr;
        end
        else if(cmd_valid & cmd_ready) begin
            data_addr <= data_addr + in_col_channel_num;
        end
    end
    assign cmd_addr = data_addr;

    reg cmd_valid_r;
    always @(posedge clk ) begin
        if(rst) begin
            cmd_valid_r <= 1'b0;
        end
        else if((state != WADDR) && (next_state == WADDR)) begin
            cmd_valid_r <= 1'b1;
        end
        else if(cmd_valid & cmd_ready) begin
            cmd_valid_r <= 1'b0;
        end    
    end
    assign cmd_valid = cmd_valid_r;

    reg [LEN_WIDTH : 0] cmd_len_r;
    always @(posedge clk ) begin
        if(start) begin
            cmd_len_r <= in_col_channel_num;
        end
    end
    assign cmd_len = cmd_len_r;


    //д��������
    reg w_double;
    always @(posedge clk) begin
        if(rst) begin
           w_double <= 1'b0;
        end
        else if(s_last & s_valid & s_ready) begin
            w_double <= !w_double;
        end
    end


    //ƹ�ҿ�����  д
    reg w_ctl;
    always @(posedge clk ) begin
        if(rst) begin
            w_ctl <= 1'b0;
        end
        else if(s_last & s_valid & s_ready & w_double) begin
            w_ctl <= !w_ctl; 
        end
    end

    assign ping_s_data  = (w_ctl == 1'b0) ? s_data : {DATA_WIDTH{1'b0}};
    assign ping_s_valid = (w_ctl == 1'b0) ? s_valid : 1'b0;
    assign ping_s_last  = (w_ctl == 1'b0) ? s_last  : 1'b0;

    assign pang_s_data  = (w_ctl == 1'b1) ? s_data : {DATA_WIDTH{1'b0}};
    assign pang_s_valid = (w_ctl == 1'b1) ? s_valid : 1'b0;
    assign pang_s_last  = (w_ctl == 1'b1) ? s_last  : 1'b0;

    assign s_ready = (w_ctl == 1'b1) ? pang_s_ready : ping_s_ready;


    //ƹ�ҿ�����  ��
    reg r_ctl;
    always @(posedge clk ) begin
        if(rst) begin
            r_ctl <= 1'b0;
        end
        else if(m_last & m_valid) begin
            r_ctl <= !r_ctl;
        end
    end

    assign ping_m_req = (r_ctl == 1'b0) ? m_req : 1'b0;
    assign pang_m_req = (r_ctl == 1'b1) ? m_req : 1'b0;

    assign m_valid = (r_ctl == 1'b0) ? ping_m_valid : pang_m_valid;
    assign m_last  = (r_ctl == 1'b0) ? ping_m_last  : pang_m_last ;
    assign m_data  = (r_ctl == 1'b0) ? ping_m_data : pang_m_data;




endmodule