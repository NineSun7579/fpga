module spram #(
    parameter DP = 1024,            //�洢��Ԫ���
    parameter DW = 8   ,            //����λ��
    parameter PIPE = 2  
) (
    input                             clk  ,
    input        [DW - 1 : 0]         wdata,
    input                             wen  ,
    input        [$clog2(DP) - 1 : 0] waddr,
    input                             ren  ,
    input        [$clog2(DP) - 1 : 0] raddr,
    output reg   [DW - 1 : 0]         rdata
);
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)
reg [DW - 1:0] mem [DP - 1 : 0];
        reg [DW - 1 : 0] rdata_temp;
// [sim-compat] module-level declarations hoisted preserving order (ModelSim use-before-decl)



always @(posedge clk ) begin
    if(wen) begin
        mem[waddr] <= wdata;
    end
end


//��PIPE��̬���ɴ����
generate
    if(PIPE == 2) begin

        always @(posedge clk) begin
            if(ren) begin
                rdata_temp <= mem[raddr];
            end
        end
        
        always @(posedge clk) begin
            rdata <= rdata_temp;
        end

    end
    else begin

        always @(posedge clk) begin
            if(ren) begin
                rdata <= mem[raddr];
            end
        end
        
    end
endgenerate

    
endmodule