`include "npu_top/config.v"
module npu_cdc_top #(
    //eth_cmd
    parameter AXI_DATA_WIDTH         = 32,
              AXI_ADDR_WIDTH         = 32,
              DDR_DATA_WIDTH_IN      = 128,          //���͸�DDR
              DDR_DATA_WIDTH_OUT     = 128,          //��DDR����
              INSTRUCTION_DATA_DEPTH = 3101,
    //npu
    parameter CHA_PAR_IN  = `CHA_PAR_IN,                           //����ͨ�����ж�
              CHA_PAR_OUT = `CHA_PAR_OUT,                           //���ͨ�����ж�
              CONV_CHA_PAR_IN = `CONV_CHA_PAR_IN,                   //�������ж�
              CONV_CHA_PAR_OUT = `CONV_CHA_PAR_OUT,
              //ͼƬ����//
              MAX_IN_COL = `MAX_IN_COL,                          //�����IMG���������
              COL_WIDTH = $clog2(MAX_IN_COL),
              MAX_IN_ROW = `MAX_IN_ROW,                          //�����IMG���������
              ROW_WIDTH = $clog2(MAX_IN_ROW),
              MAX_OUT_ROW = `MAX_OUT_ROW,                         //�����IMG���������
              //ͼƬͨ��//
              CHA_IMG_IN  = `CHA_IMG_IN,                          //�����IMG�����ͨ����
              CHA_IMG_OUT = `CHA_IMG_OUT,                         //�����IMG�����ͨ����
              //����λ��//
              INT = `INT,                                   //ÿ������λ��
              DATA_WIDTH_IN = CHA_PAR_IN * INT,             //���ݴ���λ��    ���벢�ж� * INT8
              DATA_WIDTH_OUT = CHA_PAR_OUT * INT,             //���ݴ���λ��    ���벢�ж� * INT8
              //Ȩ�ز���//
              WEIGHT_LEN =  `WEIGHT_LEN,   
              WEIGHT_LEN_WIDTH = $clog2(WEIGHT_LEN),
              WEIGHT_SUM =  `WEIGHT_SUM,   
              WEIGHT_SUM_WIDTH = $clog2(WEIGHT_SUM),
              //ƫ��λ��//
              BIAS_NUM = `BIAS_NUM ,                             //һ��ƴ�ӵ�bias����
              BIAS_LEN = (CHA_IMG_OUT / BIAS_NUM * CHA_PAR_IN) ,              //bias_len�ĳ��Ȱ���biasȫ��ͨ�������ֽ���
              BIAS_LEN_WIDTH = $clog2(BIAS_LEN),
              //�߶�λ��//
              SCALE_WIDTH = `SCALE_WIDTH,                          //scale��С��λ��
              //һ�����ݵ�����ֽ���//
              MAX_IN_LEN  = `MAX_IN_LEN,                        //��ģ�������ܵ�����ֽ���  Ҳ����һ��*��������ͨ�����ֽ���   ���ǣ����ͨ��*�������=��󳤶�
              IN_LEN_WIDTH = $clog2(MAX_IN_LEN),
              MAX_OUT_LEN = `MAX_OUT_LEN,                       //��ģ�������ܵ�����ֽ���  Ҳ����һ��*�������ͨ�����ֽ���   ���ǣ����ͨ��*�������=��󳤶�
              OUT_LEN_WIDTH = $clog2(MAX_OUT_LEN),
              //�������//
              MAX_IN_CALULATE_NUM = CHA_PAR_IN > CONV_CHA_PAR_IN ? (CHA_IMG_IN / CONV_CHA_PAR_IN) : (CHA_IMG_IN / CHA_PAR_IN),                //����ͨ���������=����ͨ����/���벢�ж� 
              IN_CALULATE_CNT_WIDTH = $clog2(MAX_IN_CALULATE_NUM),
              MAX_OUT_CALULATE_NUM = CHA_PAR_OUT > CONV_CHA_PAR_OUT ? (CHA_IMG_OUT / CONV_CHA_PAR_OUT) : (CHA_IMG_OUT / CHA_PAR_OUT),         //���ͨ���������=���ͨ����/������ж� 
              OUT_CALULATE_CNT_WIDTH = $clog2(MAX_OUT_CALULATE_NUM),
              CALULATE_NUM = MAX_IN_CALULATE_NUM * MAX_OUT_CALULATE_NUM,      //��ͨ���������=����ͨ��������� * ���ͨ��������� 
              CALULATE_CNT_WIDTH = $clog2(CALULATE_NUM),
              READ_DELAY = `READ_DELAY
)(

    input                                    npu_clk,
    input                                    npu_rst,
 
    input  wire                              axi_clk,
    input  wire                              axi_rst,
    ///////////// NPU_CTL ///////////////////////////////////
    // AXI д��ַͨ�� (AW)
    input  wire [DDR_DATA_WIDTH_IN-1 : 0]       s_axi_awaddr,
    input  wire [7 : 0]                         s_axi_awlen,    // ͻ�����ȣ�֧�� AXI4
    input  wire [2 : 0]                         s_axi_awsize,   // ͻ����С
    input  wire [1 : 0]                         s_axi_awburst,  // ͻ������
    input  wire                                 s_axi_awvalid,
    output wire                                 s_axi_awready,
    // AXI д����ͨ�� (W)
    input  wire [DDR_DATA_WIDTH_IN-1 : 0]       s_axi_wdata,
    input  wire [(DDR_DATA_WIDTH_IN/8)-1:0]     s_axi_wstrb,    // �ֽ�����
    input  wire                                 s_axi_wlast,    // ͻ�������һ�����ݱ�־
    input  wire                                 s_axi_wvalid,
    output wire                                 s_axi_wready,
    // AXI д��Ӧͨ�� (B)
    output wire [1 : 0]                         s_axi_bresp,
    output wire                                 s_axi_bvalid,
    input  wire                                 s_axi_bready,

    output                                      npu_req         , 
    input                                       npu_req_receive ,   

    ///////////// NPU_TOP ///////////////////////////////////
    //CMD_S2MM CMDMM2S�ӿ�
    //in������
    input  wire [DATA_WIDTH_IN-1 : 0]   cdc_s_data_0      ,
    input  wire                         cdc_s_valid_0     ,
    input  wire                         cdc_s_last_0      ,
    output wire                         cdc_s_ready_0     , 

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_s_cmd_addr_0  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_s_cmd_len_0   ,
    output wire                         cdc_s_cmd_valid_0 ,
    input  wire                         cdc_s_cmd_ready_0 ,
    //1
    input  wire [DATA_WIDTH_IN-1 : 0]   cdc_s_data_1      ,
    input  wire                         cdc_s_valid_1     ,
    input  wire                         cdc_s_last_1      ,
    output wire                         cdc_s_ready_1     ,

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_s_cmd_addr_1  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_s_cmd_len_1   ,
    output wire                         cdc_s_cmd_valid_1 ,
    input  wire                         cdc_s_cmd_ready_1 ,

    //2
    input  wire [DATA_WIDTH_IN-1 : 0]   cdc_s_data_2      ,
    input  wire                         cdc_s_valid_2     ,
    input  wire                         cdc_s_last_2      ,
    output wire                         cdc_s_ready_2     ,

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_s_cmd_addr_2  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_s_cmd_len_2   ,
    output wire                         cdc_s_cmd_valid_2 ,
    input  wire                         cdc_s_cmd_ready_2 ,

    //3
    input  wire [DATA_WIDTH_IN-1 : 0]   cdc_s_data_3      ,
    input  wire                         cdc_s_valid_3     ,
    input  wire                         cdc_s_last_3      ,
    output wire                         cdc_s_ready_3     , 

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_s_cmd_addr_3  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_s_cmd_len_3   ,
    output wire                         cdc_s_cmd_valid_3 ,
    input  wire                         cdc_s_cmd_ready_3 ,

    //4
    input  wire [DATA_WIDTH_IN-1 : 0]   cdc_s_data_4      ,
    input  wire                         cdc_s_valid_4     ,
    input  wire                         cdc_s_last_4      ,
    output wire                         cdc_s_ready_4     , 

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_s_cmd_addr_4  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_s_cmd_len_4   ,
    output wire                         cdc_s_cmd_valid_4 ,
    input  wire                         cdc_s_cmd_ready_4 ,

    //out�����
    output wire [DATA_WIDTH_OUT-1 : 0]  cdc_out_m_data      ,
    output wire                         cdc_out_m_last      ,
    output wire                         cdc_out_m_valid     ,
    input  wire                         cdc_out_m_ready     , 

    output wire [AXI_ADDR_WIDTH-1 : 0]  cdc_out_m_cmd_addr  ,
    output wire [AXI_DATA_WIDTH-1 : 0]  cdc_out_m_cmd_len   ,
    output wire                         cdc_out_m_cmd_valid ,
    input  wire                         cdc_out_m_cmd_ready 

);















    //CMD_S2MM CMDMM2S�ӿ�
    //in������
    wire [DATA_WIDTH_IN-1 : 0]   s_data_0      ;
    wire                         s_valid_0     ;
    wire                         s_last_0      ;
    wire                         s_ready_0     ; 
    
    wire [AXI_ADDR_WIDTH-1 : 0]  s_cmd_addr_0  ;
    wire [AXI_DATA_WIDTH-1 : 0]  s_cmd_len_0   ;
    wire                         s_cmd_valid_0 ;
    wire                         s_cmd_ready_0 ;
    //1
    wire [DATA_WIDTH_IN-1 : 0]   s_data_1      ;
    wire                         s_valid_1     ;
    wire                         s_last_1      ;
    wire                         s_ready_1     ; 
    
    wire [AXI_ADDR_WIDTH-1 : 0]  s_cmd_addr_1  ;
    wire [AXI_DATA_WIDTH-1 : 0]  s_cmd_len_1   ;
    wire                         s_cmd_valid_1 ;
    wire                         s_cmd_ready_1 ;

    //2
    wire [DATA_WIDTH_IN-1 : 0]   s_data_2      ;
    wire                         s_valid_2     ;
    wire                         s_last_2      ;
    wire                         s_ready_2     ;
    
    wire [AXI_ADDR_WIDTH-1 : 0]  s_cmd_addr_2  ;
    wire [AXI_DATA_WIDTH-1 : 0]  s_cmd_len_2   ;
    wire                         s_cmd_valid_2 ;
    wire                         s_cmd_ready_2 ;

    //3
    wire [DATA_WIDTH_IN-1 : 0]   s_data_3      ;
    wire                         s_valid_3     ;
    wire                         s_last_3      ;
    wire                         s_ready_3     ;
    
    wire [AXI_ADDR_WIDTH-1 : 0]  s_cmd_addr_3  ;
    wire [AXI_DATA_WIDTH-1 : 0]  s_cmd_len_3   ;
    wire                         s_cmd_valid_3 ;
    wire                         s_cmd_ready_3 ;

    //4
    wire [DATA_WIDTH_IN-1 : 0]   s_data_4      ;
    wire                         s_valid_4     ;
    wire                         s_last_4      ;
    wire                         s_ready_4     ;
    
    wire [AXI_ADDR_WIDTH-1 : 0]  s_cmd_addr_4  ;
    wire [AXI_DATA_WIDTH-1 : 0]  s_cmd_len_4   ;
    wire                         s_cmd_valid_4 ;
    wire                         s_cmd_ready_4 ;
    
    //out�����
    wire [DATA_WIDTH_OUT-1 : 0]   out_m_data  ;
    wire                          out_m_last  ;
    wire                          out_m_valid ;
    wire                          out_m_ready ; 
    
    wire [AXI_ADDR_WIDTH-1 : 0]   out_m_cmd_addr  ;
    wire [AXI_DATA_WIDTH-1 : 0]   out_m_cmd_len   ;
    wire                          out_m_cmd_valid ;
    wire                          out_m_cmd_ready ;
    
    
    wire                          out_calculate_end;
    wire                          out_calculate_end_receive;
    
    
    



npu_to_core_cdc_bridge #(
    .DATA_WIDTH_IN (DATA_WIDTH_IN ),
    .DATA_WIDTH_OUT(DATA_WIDTH_OUT),
    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH)
)
npu_to_core_cdc_bridge (
    // ==========================================
    // 1. ȫ��ʱ���븴λ�ź� (�ߵ�ƽ��Ч)
    // ==========================================
    .npu_clk(npu_clk),
    .npu_rst(npu_rst),   // NPU�ิλ (�ߵ�ƽ��Ч)
    .axi_clk(axi_clk),
    .axi_rst(axi_rst),   // AXI�ิλ (�ߵ�ƽ��Ч)

    // ==========================================
    // 2. NPU ��ӿ� (������ npu_clk ʱ����)
    // ==========================================
    // -- Data ͨ�� 0-4 (Core ���� NPU -> Bridge ���) --
    .s_data_0(s_data_0),       .s_valid_0(s_valid_0),       .s_last_0(s_last_0),       .s_ready_0(s_ready_0),
    .s_data_1(s_data_1),       .s_valid_1(s_valid_1),       .s_last_1(s_last_1),       .s_ready_1(s_ready_1),
    .s_data_2(s_data_2),       .s_valid_2(s_valid_2),       .s_last_2(s_last_2),       .s_ready_2(s_ready_2),
    .s_data_3(s_data_3),       .s_valid_3(s_valid_3),       .s_last_3(s_last_3),       .s_ready_3(s_ready_3),
    .s_data_4(s_data_4),       .s_valid_4(s_valid_4),       .s_last_4(s_last_4),       .s_ready_4(s_ready_4),

    // -- Cmd ͨ�� 0-4 (NPU ���� Core -> Bridge ����) --
    .s_cmd_addr_0(s_cmd_addr_0), .s_cmd_len_0(s_cmd_len_0), .s_cmd_valid_0(s_cmd_valid_0), .s_cmd_ready_0(s_cmd_ready_0),
    .s_cmd_addr_1(s_cmd_addr_1), .s_cmd_len_1(s_cmd_len_1), .s_cmd_valid_1(s_cmd_valid_1), .s_cmd_ready_1(s_cmd_ready_1),
    .s_cmd_addr_2(s_cmd_addr_2), .s_cmd_len_2(s_cmd_len_2), .s_cmd_valid_2(s_cmd_valid_2), .s_cmd_ready_2(s_cmd_ready_2),
    .s_cmd_addr_3(s_cmd_addr_3), .s_cmd_len_3(s_cmd_len_3), .s_cmd_valid_3(s_cmd_valid_3), .s_cmd_ready_3(s_cmd_ready_3),
    .s_cmd_addr_4(s_cmd_addr_4), .s_cmd_len_4(s_cmd_len_4), .s_cmd_valid_4(s_cmd_valid_4), .s_cmd_ready_4(s_cmd_ready_4),

    // -- Out ���ͨ�� (NPU ���� Core -> Bridge ����) --
    .out_m_data(out_m_data),         .out_m_last(out_m_last),         .out_m_valid(out_m_valid),         .out_m_ready(out_m_ready),
    .out_m_cmd_addr(out_m_cmd_addr), .out_m_cmd_len(out_m_cmd_len),   .out_m_cmd_valid(out_m_cmd_valid), .out_m_cmd_ready(out_m_cmd_ready),

    // ==========================================
    // 3. AXI Core ��ӿ� (������ axi_clk ʱ����)
    // ==========================================
    // -- Data ͨ�� 0-4 (Core ���� NPU -> Bridge ����) --
    .cdc_s_data_0(cdc_s_data_0), .cdc_s_valid_0(cdc_s_valid_0), .cdc_s_last_0(cdc_s_last_0), .cdc_s_ready_0(cdc_s_ready_0),
    .cdc_s_data_1(cdc_s_data_1), .cdc_s_valid_1(cdc_s_valid_1), .cdc_s_last_1(cdc_s_last_1), .cdc_s_ready_1(cdc_s_ready_1),
    .cdc_s_data_2(cdc_s_data_2), .cdc_s_valid_2(cdc_s_valid_2), .cdc_s_last_2(cdc_s_last_2), .cdc_s_ready_2(cdc_s_ready_2),
    .cdc_s_data_3(cdc_s_data_3), .cdc_s_valid_3(cdc_s_valid_3), .cdc_s_last_3(cdc_s_last_3), .cdc_s_ready_3(cdc_s_ready_3),
    .cdc_s_data_4(cdc_s_data_4), .cdc_s_valid_4(cdc_s_valid_4), .cdc_s_last_4(cdc_s_last_4), .cdc_s_ready_4(cdc_s_ready_4),

    // -- Cmd ͨ�� 0-4 (NPU ���� Core -> Bridge ���) --
    .cdc_s_cmd_addr_0(cdc_s_cmd_addr_0), .cdc_s_cmd_len_0(cdc_s_cmd_len_0), .cdc_s_cmd_valid_0(cdc_s_cmd_valid_0), .cdc_s_cmd_ready_0(cdc_s_cmd_ready_0),
    .cdc_s_cmd_addr_1(cdc_s_cmd_addr_1), .cdc_s_cmd_len_1(cdc_s_cmd_len_1), .cdc_s_cmd_valid_1(cdc_s_cmd_valid_1), .cdc_s_cmd_ready_1(cdc_s_cmd_ready_1),
    .cdc_s_cmd_addr_2(cdc_s_cmd_addr_2), .cdc_s_cmd_len_2(cdc_s_cmd_len_2), .cdc_s_cmd_valid_2(cdc_s_cmd_valid_2), .cdc_s_cmd_ready_2(cdc_s_cmd_ready_2),
    .cdc_s_cmd_addr_3(cdc_s_cmd_addr_3), .cdc_s_cmd_len_3(cdc_s_cmd_len_3), .cdc_s_cmd_valid_3(cdc_s_cmd_valid_3), .cdc_s_cmd_ready_3(cdc_s_cmd_ready_3),
    .cdc_s_cmd_addr_4(cdc_s_cmd_addr_4), .cdc_s_cmd_len_4(cdc_s_cmd_len_4), .cdc_s_cmd_valid_4(cdc_s_cmd_valid_4), .cdc_s_cmd_ready_4(cdc_s_cmd_ready_4),

    // -- Out ���ͨ�� (NPU ���� Core -> Bridge ���) --
    .cdc_out_m_data(cdc_out_m_data),         .cdc_out_m_last(cdc_out_m_last),         .cdc_out_m_valid(cdc_out_m_valid),         .cdc_out_m_ready(cdc_out_m_ready),
    .cdc_out_m_cmd_addr(cdc_out_m_cmd_addr), .cdc_out_m_cmd_len(cdc_out_m_cmd_len),   .cdc_out_m_cmd_valid(cdc_out_m_cmd_valid), .cdc_out_m_cmd_ready(cdc_out_m_cmd_ready)
);












    //REG��AXI_lite�ӿ�
    wire                              m_axi_awvalid;
    wire                              m_axi_awready; 
    wire  [AXI_ADDR_WIDTH-1 : 0]      m_axi_awaddr ;

    wire                              m_axi_wvalid;
    wire                              m_axi_wready; 
    wire  [AXI_DATA_WIDTH-1 : 0]      m_axi_wdata ;
    wire  [AXI_DATA_WIDTH/8-1 : 0]    m_axi_wstrb ;

    wire                              m_axi_bvalid;
    wire                              m_axi_bready;
    wire  [1 : 0]                     m_axi_bresp ;
 
    wire                              m_axi_arvalid; 
    wire                              m_axi_arready; 
    wire  [AXI_ADDR_WIDTH-1 : 0]      m_axi_araddr ;

    wire                              m_axi_rvalid;
    wire                              m_axi_rready; 
    wire  [AXI_DATA_WIDTH-1 : 0]      m_axi_rdata ;
    wire  [1 : 0]                     m_axi_rresp ;




    npu_ctl #(
        .AXI_DATA_WIDTH(DDR_DATA_WIDTH_IN),
        .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
        .INSTRUCTION_DATA_DEPTH(INSTRUCTION_DATA_DEPTH),          //�����ָ����
        .NPU_LAYER(120)
    )
    npu_ctl(
        // ȫ��ʱ���븴λ
        .axi_clk(axi_clk),
        .axi_rst(axi_rst),

        // AXI д��ַͨ�� (AW)
        .s_axi_awaddr (s_axi_awaddr ),
        .s_axi_awlen  (s_axi_awlen  ),    // ͻ�����ȣ�֧�� AXI4
        .s_axi_awsize (s_axi_awsize ),   // ͻ����С
        .s_axi_awburst(s_axi_awburst),  // ͻ������
        .s_axi_awvalid(s_axi_awvalid),
        .s_axi_awready(s_axi_awready),

        // AXI д����ͨ�� (W)
        .s_axi_wdata (s_axi_wdata ),
        .s_axi_wstrb (s_axi_wstrb ),    // �ֽ�����
        .s_axi_wlast (s_axi_wlast ),    // ͻ�������һ�����ݱ�־
        .s_axi_wvalid(s_axi_wvalid),
        .s_axi_wready(s_axi_wready),

        // AXI д��Ӧͨ�� (B)
        .s_axi_bresp (s_axi_bresp ),
        .s_axi_bvalid(s_axi_bvalid),
        .s_axi_bready(s_axi_bready),


        ////////////////////////////////////////////////////////////
        //�û��߼�
        .npu_clk(npu_clk),
        .npu_rst(npu_rst),

        //REG��AXI_lite�ӿ�
        .m_axi_awvalid(m_axi_awvalid),
        .m_axi_awready(m_axi_awready), 
        .m_axi_awaddr (m_axi_awaddr ),

        .m_axi_wvalid (m_axi_wvalid ),
        .m_axi_wready (m_axi_wready ), 
        .m_axi_wdata  (m_axi_wdata  ),
        .m_axi_wstrb  (m_axi_wstrb  ),

        .m_axi_bvalid (m_axi_bvalid ),
        .m_axi_bready (m_axi_bready ),
        .m_axi_bresp  (m_axi_bresp  ),

        .m_axi_arvalid(m_axi_arvalid), 
        .m_axi_arready(m_axi_arready), 
        .m_axi_araddr (m_axi_araddr ), 

        .m_axi_rvalid (m_axi_rvalid ),
        .m_axi_rready (m_axi_rready ), 
        .m_axi_rdata  (m_axi_rdata  ),
        .m_axi_rresp  (m_axi_rresp  ),


        .calculate_end        (out_calculate_end        ),
        .calculate_end_receive(out_calculate_end_receive),   

        .npu_req        (npu_req        ) , 
        .npu_req_receive(npu_req_receive) 


    );




    wire [DATA_WIDTH_OUT-1 : 0] m_data ;
    wire                        m_last ;
    wire                        m_valid;
    wire                        m_ready;

    // ==========================================
    // NPU ʱ���ſأ���� 150MHz NPU ���� OV5640 I2C ��ʼ��ʧ�ܵ�����
    // ==========================================
    // ����npu_clk(150MHz) �� OV5640 ����ͬһ�� PLL(ov5640_clk)��
    // NPU ���� DSP/BRAM �� 150MHz �·�ת������Դ������ͨ�� PLL ���
    // �� clk_50m������ OV5640 I2C ʱ��ʧ�ܡ�
    // �������ϵ���ӳ� ~50ms �ٸ� npu_top ʱ�ӣ��� OV5640 I2C ����ɳ�ʼ����
    // ==========================================
    localparam NPU_CLK_DELAY_CYCLES = 24'd7_500_000; // 50ms @ 150MHz

    reg  [23:0] npu_clk_delay_cnt;
    reg         npu_clk_en_req;
    reg         npu_clk_en_latch;
    wire        npu_clk_gated;

    // �ӳټ��������� npu_rst �ͷź���� NPU_CLK_DELAY_CYCLES ������
    always @(posedge npu_clk or posedge npu_rst) begin
        if (npu_rst) begin
            npu_clk_delay_cnt <= 24'd0;
            npu_clk_en_req    <= 1'b0;
        end
        else if (!npu_clk_en_req) begin
            if (npu_clk_delay_cnt < NPU_CLK_DELAY_CYCLES)
                npu_clk_delay_cnt <= npu_clk_delay_cnt + 1'b1;
            else
                npu_clk_en_req <= 1'b1;
        end
    end

    // �½������棺��׼��ë��ʱ���ſ� (glitch-free clock gating)
    always @(negedge npu_clk or posedge npu_rst) begin
        if (npu_rst)
            npu_clk_en_latch <= 1'b0;
        else
            npu_clk_en_latch <= npu_clk_en_req;
    end

    GTP_CLKBUFGCE #(
        .DEFAULT_VALUE(1'b0),
        .SIM_DEVICE("LOGOS2")
    ) u_bufgce_npu (
        .CLKOUT(npu_clk_gated),
        .CE    (npu_clk_en_latch),
        .CLKIN (npu_clk)
    );

    npu_top # (
        .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
        .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
        //���ж�//
        .CHA_PAR_IN (CHA_PAR_IN ),                          //����ͨ�����ж�
        .CHA_PAR_OUT(CHA_PAR_OUT),                          //���ͨ�����ж�
        .CONV_CHA_PAR_IN (CONV_CHA_PAR_IN ),                //��������ͨ�����ж�
        .CONV_CHA_PAR_OUT(CONV_CHA_PAR_OUT),                //�������ͨ�����ж�
        //ͼƬ����//
        .MAX_IN_COL (MAX_IN_COL ),                          //�����IMG���������
        .MAX_IN_ROW (MAX_IN_ROW ),                          //�����IMG���������
        .MAX_OUT_ROW(MAX_OUT_ROW),                          //�����IMG���������
        //ͼƬͨ��//
        .CHA_IMG_IN (CHA_IMG_IN ),                          //�����IMG�����ͨ����
        .CHA_IMG_OUT(CHA_IMG_OUT),                          //�����IMG�����ͨ����
        //����λ��//
        .INT(INT),                                          //ÿ������λ��
        .WEIGHT_LEN(WEIGHT_LEN),   
        .WEIGHT_SUM(WEIGHT_SUM), 
        //ƫ��λ��//
        .BIAS_NUM(BIAS_NUM),                                //һ��ƴ�ӵ�bias����
        //�߶�λ��//
        .SCALE_WIDTH(SCALE_WIDTH),                          //scale��С��λ��
        //һ�����ݵ�����ֽ���//
        .MAX_IN_LEN (MAX_IN_LEN ),                          //��ģ�������ܵ�����ֽ���  Ҳ����һ��*��������ͨ�����ֽ���   ���ǣ����ͨ��*�������=��󳤶�
        .MAX_OUT_LEN(MAX_OUT_LEN),                          //��ģ�������ܵ�����ֽ���  Ҳ����һ��*�������ͨ�����ֽ���   ���ǣ����ͨ��*�������=��󳤶�
        .READ_DELAY (READ_DELAY )
    )
    npu_top_inst(
    
        .clk(npu_clk_gated),
        .rst(npu_rst),
    
    
        //REG�Ĵ���ӿ� ��AXI_lite��
        .s_axi_awvalid(m_axi_awvalid)  ,
        .s_axi_awready(m_axi_awready)  , 
        .s_axi_awaddr (m_axi_awaddr )  ,

        .s_axi_wvalid (m_axi_wvalid)   ,
        .s_axi_wready (m_axi_wready)   , 
        .s_axi_wdata  (m_axi_wdata )   ,
        .s_axi_wstrb  (m_axi_wstrb )   ,

        .s_axi_bvalid (m_axi_bvalid)   ,
        .s_axi_bready (m_axi_bready)   ,
        .s_axi_bresp  (m_axi_bresp )   ,

        .s_axi_arvalid(m_axi_arvalid)  , 
        .s_axi_arready(m_axi_arready)  , 
        .s_axi_araddr (m_axi_araddr )  ,

        .s_axi_rvalid (m_axi_rvalid)   ,
        .s_axi_rready (m_axi_rready)   , 
        .s_axi_rdata  (m_axi_rdata )   ,
        .s_axi_rresp  (m_axi_rresp )   ,
    
    
        //in������
        .s_data_0 (s_data_0 )     ,
        .s_valid_0(s_valid_0)     ,
        .s_last_0 (s_last_0 )     ,
        .s_ready_0(s_ready_0)     , 

        .s_cmd_addr_0 (s_cmd_addr_0 ) ,
        .s_cmd_len_0  (s_cmd_len_0  ) ,
        .s_cmd_valid_0(s_cmd_valid_0) ,
        .s_cmd_ready_0(s_cmd_ready_0) ,
        //1
        .s_data_1 (s_data_1 )     ,
        .s_valid_1(s_valid_1)     ,
        .s_last_1 (s_last_1 )     ,
        .s_ready_1(s_ready_1)     , 

        .s_cmd_addr_1 (s_cmd_addr_1 ) ,
        .s_cmd_len_1  (s_cmd_len_1  ) ,
        .s_cmd_valid_1(s_cmd_valid_1) ,
        .s_cmd_ready_1(s_cmd_ready_1) ,

        //2 para_conv_weight
        .s_data_2 (s_data_2 )     ,
        .s_valid_2(s_valid_2)     ,
        .s_last_2 (s_last_2 )     ,
        .s_ready_2(s_ready_2)     , 

        .s_cmd_addr_2 (s_cmd_addr_2 ) ,
        .s_cmd_len_2  (s_cmd_len_2  ) ,
        .s_cmd_valid_2(s_cmd_valid_2) ,
        .s_cmd_ready_2(s_cmd_ready_2) ,

        //3 para_cat_add_0
        .s_data_3 (s_data_3 )     ,
        .s_valid_3(s_valid_3)     ,
        .s_last_3 (s_last_3 )     ,
        .s_ready_3(s_ready_3)     , 

        .s_cmd_addr_3 (s_cmd_addr_3 ) ,
        .s_cmd_len_3  (s_cmd_len_3  ) ,
        .s_cmd_valid_3(s_cmd_valid_3) ,
        .s_cmd_ready_3(s_cmd_ready_3) ,

        //4 para_cat_add_1
        .s_data_4 (s_data_4 )     ,
        .s_valid_4(s_valid_4)     ,
        .s_last_4 (s_last_4 )     ,
        .s_ready_4(s_ready_4)     , 

        .s_cmd_addr_4 (s_cmd_addr_4 ) ,
        .s_cmd_len_4  (s_cmd_len_4  ) ,
        .s_cmd_valid_4(s_cmd_valid_4) ,
        .s_cmd_ready_4(s_cmd_ready_4) ,

        //out�����
        .out_m_data (m_data ) ,
        .out_m_last (m_last ) ,
        .out_m_valid(m_valid) ,
        .out_m_ready(m_ready) , 

        .out_m_cmd_addr (out_m_cmd_addr ) ,
        .out_m_cmd_len  (out_m_cmd_len  ) ,
        .out_m_cmd_valid(out_m_cmd_valid) ,
        .out_m_cmd_ready(out_m_cmd_ready) ,

        .out_calculate_end        (out_calculate_end        ),//////////////////
        .out_calculate_end_receive(out_calculate_end_receive)

    );


    


    pipe #(
        .WIDTH(DATA_WIDTH_OUT+1)
    )
    pipe_out(
        .clk(npu_clk),
        .rst(npu_rst),

        .up_valid(m_valid),
        .up_ready(m_ready),
        .data_in ({m_last, m_data}),


        .down_valid(out_m_valid),
        .down_ready(out_m_ready),
        .data_out  ({out_m_last, out_m_data})
    );


endmodule