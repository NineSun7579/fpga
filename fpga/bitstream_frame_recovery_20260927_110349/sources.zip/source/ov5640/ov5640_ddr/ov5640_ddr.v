module ov5640_ddr #(
    parameter DATA_WIDTH = 16,
    parameter AXI_ADDR_WIDTH = 32,
    parameter AXI_LEN_WIDTH  = 32,
    parameter AXI_DATA_WIDTH = 128,
    parameter CAM_DATA_LEN   = 172800, //1280*720*3/16
    parameter DEVICE = "PG"
)(
    input          axi_clk        ,
    input          axi_rst        , 
    input          dma_abort,
    output         dma_abort_req,
    input          dma_done       ,  // [LEDGER 2026-09-19] DMA transaction-done pulse
    input          axi_cam_en     ,      //����ͷ�����ź�

    input  [AXI_ADDR_WIDTH-1 : 0]      cam_data_addr_1,
    input  [AXI_ADDR_WIDTH-1 : 0]      cam_data_addr_2,
    input  [$clog2(CAM_DATA_LEN) : 0]  cam_data_len   , //��16�ֽ�Ϊ��λ

    input  [DATA_WIDTH-1 : 0]  s_data         /*synthesis PAP_MARK_DEBUG="1"*/,
    input                      s_data_valid   /*synthesis PAP_MARK_DEBUG="1"*/,
    input                      s_hsync        /*synthesis PAP_MARK_DEBUG="1"*/,
    input                      s_vsync        /*synthesis PAP_MARK_DEBUG="1"*/,

    output [AXI_DATA_WIDTH-1 : 0] axi_data       /*synthesis PAP_MARK_DEBUG="1"*/,
    output                        axi_data_valid /*synthesis PAP_MARK_DEBUG="1"*/,
    output                        axi_data_last  /*synthesis PAP_MARK_DEBUG="1"*/, 
    input                         axi_data_ready /*synthesis PAP_MARK_DEBUG="1"*/,

    output [AXI_ADDR_WIDTH-1 : 0]  axi_cmd_addr   /*synthesis PAP_MARK_DEBUG="1"*/,
    output [AXI_LEN_WIDTH-1 : 0]   axi_cmd_len    /*synthesis PAP_MARK_DEBUG="1"*/,
    output                         axi_cmd_valid  /*synthesis PAP_MARK_DEBUG="1"*/,
    input                          axi_cmd_ready  /*synthesis PAP_MARK_DEBUG="1"*/,

    output [1 : 0]   xdma_req       ,
    output [31:0]    dbg_axi_cnt    ,
    output [31:0]    dbg_axi_num    ,
    output [31:0]    dbg_zdin       ,
    output [31:0]    dbg_zout       ,
    output [31:0]    dbg_state      ,
    output [31:0]    dbg_last_cnt   ,
    output [31:0]    dbg_wd_cnt     ,
    input  [1 : 0]   xdma_ack        ,
    output [AXI_ADDR_WIDTH-1:0] prev_frame_base  // [VKFS] previous frame's ping-pong bank
);

    wire [DATA_WIDTH-1 : 0]  m_data      /*synthesis PAP_MARK_DEBUG="1"*/;
    wire                     m_data_valid/*synthesis PAP_MARK_DEBUG="1"*/;
    wire                     m_hsync     /*synthesis PAP_MARK_DEBUG="1"*/;
    wire                     m_vsync     /*synthesis PAP_MARK_DEBUG="1"*/;

    // [FRTAG 2026-09-14] frame-tag plumbing: the packer stream is detoured through
    // w_* and the ctrl can substitute one counter beat during its DATA_TAG state.
    wire [AXI_DATA_WIDTH-1 : 0] w_data  ;
    wire                        w_valid ;
    wire                        w_last  ;
    wire                        w_ready ;
    wire                        frame_active;
    wire                        tag_active;
    wire [AXI_DATA_WIDTH-1 : 0] tag_data  ;
    wire                    engine_busy;   // [IDLEGATE 2026-09-19]
    wire                    w_ping_o;


// Capture validity belongs to the admitted SOF, never to a DMA timeout.
// Flush only on DMA retirement (all external W/B obligations are finished).
reg [2:0] flush_count;
wire capture_flush = (flush_count != 0);
reg capture_open, capture_bad;
reg [31:0] pixel_count, pixel_limit;
reg raw_vsync_q;
wire raw_sof = s_vsync && !raw_vsync_q;
wire capture_overflow;
wire capture_complete = capture_open && (pixel_count == pixel_limit);
wire frame_good = capture_complete && !capture_bad && !capture_overflow;
wire capture_stop = capture_flush || capture_bad || capture_complete;
assign dma_abort_req = capture_bad;
always @(posedge axi_clk) begin
    if(axi_rst) begin
        flush_count <= 4;
        raw_vsync_q <= 0;
    end else begin
        raw_vsync_q <= s_vsync;
        if(dma_abort || (dma_done && (!frame_active || !frame_good))) flush_count <= 4;
        else if(capture_flush) flush_count <= flush_count - 1'b1;
    end
end
always @(posedge axi_clk) begin
    if(axi_rst || capture_flush) begin
        capture_open <= 0;
        capture_bad <= 0;
        pixel_count <= 0;
        pixel_limit <= 0;
    end else if(m_vsync) begin
        capture_open <= 1;
        capture_bad <= (cam_data_len == 0);
        pixel_count <= 0;
        pixel_limit <= (cam_data_len * AXI_DATA_WIDTH) / DATA_WIDTH;
    end else if(capture_open) begin
        if(m_data_valid) pixel_count <= pixel_count + 1'b1;
        if(capture_overflow || (raw_sof && !capture_complete)) capture_bad <= 1;
    end
end

ov5640_ddr_w_en #(
    .DATA_WIDTH(DATA_WIDTH)
)
ov5640_ddr_w_en(
    .capture_stop  (capture_stop),
    .engine_busy   (engine_busy | capture_flush),   // [IDLEGATE 2026-09-19] gate admission on write-engine idle
    .axi_clk       (axi_clk        ),
    .axi_rst       (axi_rst        ),

    .axi_cam_en    (axi_cam_en),
    .frame_pending (xdma_req),

    .s_data        (s_data         ),
    .s_data_valid  (s_data_valid   ),
    .s_hsync       (s_hsync        ),
    .s_vsync       (s_vsync        ),

    .m_data        (m_data         ),
    .m_data_valid  (m_data_valid   ),
    .m_hsync       (m_hsync        ),
    .m_vsync       (m_vsync        )
);



ov5640_ddr_w #(
    .DATA_WIDTH(DATA_WIDTH),
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
    .CAM_DATA_LEN(CAM_DATA_LEN),
    .DEVICE(DEVICE)
) 
ov5640_ddr_w(
    .axi_clk        (axi_clk        ),
    .axi_rst        (axi_rst        ),

    .capture_flush (capture_flush),
    .capture_overflow(capture_overflow),
    .data_len       (cam_data_len   ), //��16�ֽ�Ϊ��λ

    .s_data         (m_data         ),
    .s_data_valid   (m_data_valid   ),
    .s_hsync        (m_hsync        ),
    .s_vsync        (m_vsync        ),

    .axi_data       (w_data         ),
    .axi_data_valid (w_valid        ),
    .axi_data_last  (w_last         ),
    .axi_data_ready (w_ready        ),
    .dbg_axi_cnt    (dbg_axi_cnt    ),
    .dbg_axi_num    (dbg_axi_num    ),
    .dbg_zdin       (dbg_zdin       ),
    .dbg_zout       (dbg_zout       )
);

    // Only DATA may consume camera FIFO words. DATA_TAG presents one tag
    // beat; WAIT_TAG_DONE presents no data and retains engine ownership.
    assign axi_data       = tag_active ? tag_data : w_data;
    assign axi_data_valid = tag_active | (frame_active & w_valid);
    assign axi_data_last  = w_last;
    assign w_ready        = axi_data_ready & frame_active;




ov5640_ddr_w_ctrl #(
    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
    .AXI_LEN_WIDTH (AXI_LEN_WIDTH ),
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
    .CAM_DATA_LEN  (CAM_DATA_LEN  )  //1280*720*3/16
)
ov5640_ddr_w_ctrl(
    .axi_clk        (axi_clk        ),
    .axi_rst        (axi_rst        ),

    .cam_data_addr_1(cam_data_addr_1),
    .cam_data_addr_2(cam_data_addr_2),
    .cam_data_len   (cam_data_len   ),
    
    .s_vsync        (m_vsync        ),

    .dma_abort      (dma_abort),
    .frame_good     (frame_good),
    .dma_done       (dma_done       ),  // [LEDGER 2026-09-19]

    .axi_cmd_addr   (axi_cmd_addr   ),
    .axi_cmd_len    (axi_cmd_len    ),
    .axi_cmd_valid  (axi_cmd_valid  ),
    .axi_cmd_ready  (axi_cmd_ready  ),

    .frame_active   (frame_active   ),
    .tag_active     (tag_active     ),
    .tag_data       (tag_data       ),
    .tag_ready      (axi_data_ready ),

    .engine_busy    (engine_busy    ),
    .w_ping_o       (w_ping_o       ),
    .dbg_state      (dbg_state      ),
    .dbg_last_cnt   (dbg_last_cnt   ),
    .dbg_wd_cnt     (dbg_wd_cnt     ),
    .xdma_req       (xdma_req       ),
    .xdma_ack       (xdma_ack       )
);


    
    // [VKFS 2026-09-25] prev frame base = the bank NOT currently being written
    assign prev_frame_base = w_ping_o ? cam_data_addr_1 : cam_data_addr_2;

endmodule
